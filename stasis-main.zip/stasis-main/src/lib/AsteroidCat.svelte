<script lang="ts">
	import { onMount } from 'svelte';
	
	let asteroidPosition = $state<{ x: number; y: number; rotation: number } | null>(null);
	let showAsteroid = $state(false);
	let smokeParticles = $state<Array<{ id: number; x: number; y: number; image: number; rotation: number; opacity: number; size: number }>>([]);
	let particleIdCounter = 0;
	let holePosition = $state<{ x: number; y: number } | null>(null);
	let showHole = $state(false);
	let holeOpacity = $state(1);
	let shakeTransform = $state('');
	let Oneko: any = null;
	let isFlashing = $state(false);
	let isLandingFlash = $state(false);

	onMount(async () => {
		const module = await import('lots-o-nekos');
		Oneko = module.Oneko;
	});

	const calculateRandomPortalPosition = () => {
		const viewportWidth = window.innerWidth;
		const viewportHeight = window.innerHeight;
		
		const remInPx = parseFloat(getComputedStyle(document.documentElement).fontSize);
		const centerX = viewportWidth / 2;
		
		// Choose left or right side randomly
		const isLeftSide = Math.random() < 0.5;
		
		let x: number;
		if (isLeftSide) {
			// Left side: 3.5rem from left to (center - 14.5rem)
			const minX = 3.5 * remInPx;
			const maxX = centerX - 14.5 * remInPx;
			x = minX + Math.random() * (maxX - minX);
		} else {
			// Right side: (center + 14.5rem) to (width - 3.5rem)
			const minX = centerX + 14.5 * remInPx;
			const maxX = viewportWidth - 3.5 * remInPx;
			x = minX + Math.random() * (maxX - minX);
		}
		
		// Vertical: Bottom half of screen (from halfway down to 4rem from bottom)
		const minY = viewportHeight / 2;
		const maxY = viewportHeight - 4 * remInPx;
		const y = minY + Math.random() * (maxY - minY);
		
		return { x, y };
	};

	const spawnImpactCloud = async (centerX: number, centerY: number) => {
		// Spawn 20-30 smoke particles in a cloud around the impact point
		const particleCount = 20 + Math.floor(Math.random() * 11);
		
		for (let i = 0; i < particleCount; i++) {
			// Random position within a radius around the impact
			const angle = Math.random() * Math.PI * 2;
			const radius = Math.random() * 25; // Up to 25px from center
			const x = centerX + Math.cos(angle) * radius;
			const y = centerY + Math.sin(angle) * radius;
			
			// Store the outward direction
			const outwardAngle = angle;
			
			// Spawn with slight delay for more natural appearance
			setTimeout(() => {
				spawnSmokeParticle(x, y, outwardAngle);
			}, Math.random() * 100);
		}
	};

	const spawnSmokeParticle = async (x: number, y: number, outwardAngle?: number) => {
		const gsap = await import('gsap');
		
		const cardinalRotations = [0, 90, 180, 270];
		
		// If outwardAngle provided, move outward first then random
		let driftX: number;
		let driftY: number;
		
		if (outwardAngle !== undefined) {
			// Initial outward push
			const outwardDist = 20 + Math.random() * 20; // 20-40px outward
			driftX = Math.cos(outwardAngle) * outwardDist + (Math.random() - 0.5) * 15;
			driftY = Math.sin(outwardAngle) * outwardDist + (Math.random() - 0.5) * 15;
		} else {
			// Random drift direction for trail smoke
			driftX = (Math.random() - 0.5) * 30; // -15 to +15 px
			driftY = (Math.random() - 0.5) * 30; // -15 to +15 px
		}
		
		const particleId = particleIdCounter++;
		const particleImage = Math.floor(Math.random() * 5) + 1;
		const particleRotation = cardinalRotations[Math.floor(Math.random() * 4)];
		const particleSize = 0.8 + Math.random() * 0.6;
		
		const particle = {
			id: particleId,
			x,
			y,
			image: particleImage,
			rotation: particleRotation,
			opacity: 1,
			size: particleSize
		};
		
		smokeParticles = [...smokeParticles, particle];
		
		// Create plain object for GSAP animation
		const animState = { x, y, opacity: 1 };
		
		// Drift movement (linear, no delay)
		gsap.default.to(animState, {
			x: x + driftX,
			y: y + driftY,
			duration: 1.5,
			ease: 'none', // Linear movement
			onUpdate: () => {
				// Update by replacing the particle with a new object
				smokeParticles = smokeParticles.map(p => 
					p.id === particleId 
						? { ...p, x: animState.x, y: animState.y, opacity: animState.opacity }
						: p
				);
			}
		});
		
		// Fade out (delayed)
		gsap.default.to(animState, {
			opacity: 0,
			duration: 1.0,
			delay: 0.5, // Wait 0.5s before starting to fade
			ease: 'power1.out',
			onUpdate: () => {
				smokeParticles = smokeParticles.map(p => 
					p.id === particleId 
						? { ...p, opacity: animState.opacity }
						: p
				);
			},
			onComplete: () => {
				smokeParticles = smokeParticles.filter(p => p.id !== particleId);
			}
		});
	};

	const shakeScreen = async (catElement?: HTMLElement) => {
		const gsap = await import('gsap');
		
		const pageWrapper = (window as any).__stasisPageWrapper;
		
		const amplitude = { value: 1 };
		const shakeTarget = { x: 0, y: 0 };
		const catShakeTarget = { x: 0, y: 0 };
		const pageShakeTarget = { x: 0, y: 0 };
		
		// Fade out amplitude over time
		gsap.default.to(amplitude, {
			value: 0,
			duration: 0.8,
			ease: 'power2.out'
		});
		
		// Shake our effects container (smoke, hole, asteroid)
		gsap.default.to(shakeTarget, {
			x: '+=16',
			y: '+=16',
			duration: 0.05,
			yoyo: true,
			repeat: 15,
			ease: 'power2.out',
			onUpdate: () => {
				const x = shakeTarget.x * amplitude.value;
				const y = shakeTarget.y * amplitude.value;
				shakeTransform = `translate(${x}px, ${y}px)`;
			},
			onComplete: () => {
				shakeTransform = '';
			}
		});
		
		// Shake the cat separately using its own transform
		if (catElement) {
			gsap.default.to(catShakeTarget, {
				x: '+=16',
				y: '+=16',
				duration: 0.05,
				yoyo: true,
				repeat: 15,
				ease: 'power2.out',
				onUpdate: () => {
					const x = catShakeTarget.x * amplitude.value;
					const y = catShakeTarget.y * amplitude.value;
					catElement.style.transform = `translate(-50%, -50%) translate(${x}px, ${y}px)`;
				},
				onComplete: () => {
					catElement.style.transform = 'translate(-50%, -50%)';
				}
			});
		}
		
		// Shake the page wrapper (everything else)
		if (pageWrapper) {
			gsap.default.to(pageShakeTarget, {
				x: '+=16',
				y: '+=16',
				duration: 0.05,
				yoyo: true,
				repeat: 15,
				ease: 'power2.out',
				onUpdate: () => {
					const x = pageShakeTarget.x * amplitude.value;
					const y = pageShakeTarget.y * amplitude.value;
					pageWrapper.style.transform = `translate(${x}px, ${y}px)`;
				},
				onComplete: () => {
					pageWrapper.style.transform = '';
				}
			});
		}
	};

	const animateAsteroid = async (targetX: number, targetY: number) => {
		const gsap = await import('gsap');
		
		// Disable scrolling
		document.body.style.overflow = 'hidden';
		
		const viewportWidth = window.innerWidth;
		const centerX = viewportWidth / 2;
		const isRightSide = targetX > centerX;
		
		// 60 degrees from horizontal = 30 degrees from vertical: tan(30°) ≈ 0.577
		const angle = Math.tan(30 * Math.PI / 180);
		const buffer = 50; // Start just off screen
		
		// Calculate starting position
		const verticalDistance = targetY + buffer;
		const horizontalOffset = verticalDistance * angle;
		
		let startX: number;
		if (isRightSide) {
			// Coming from top-left
			startX = targetX - horizontalOffset;
		} else {
			// Coming from top-right
			startX = targetX + horizontalOffset;
		}
		
		const startY = -buffer;
		
		// Create a plain object for GSAP to animate
		const animationState = { x: startX, y: startY, rotation: 0 };
		
		// Set initial position
		asteroidPosition = { ...animationState };
		showAsteroid = true;
		
		// Animate to target
		gsap.default.to(animationState, {
			x: targetX,
			y: targetY,
			rotation: 720, // Two full rotations
			duration: 2,
			ease: 'power1.in',
			onUpdate: function() {
				asteroidPosition = { ...animationState };
				
				// Spawn smoke particles randomly (60-80% chance per frame)
				if (Math.random() < 0.7) {
					spawnSmokeParticle(animationState.x, animationState.y);
				}
			},
			onComplete: () => {
				// Flash landing
				setTimeout(() => {
					isLandingFlash = true;
					setTimeout(() => {
						isLandingFlash = false;
					}, 2500);
				}, 25);

				// Hide asteroid
				showAsteroid = false;
				
				// Show hole at impact point (slightly lower)
				holePosition = { x: targetX, y: targetY + 3 };
				showHole = true;
				holeOpacity = 1;
				
				// Spawn impact smoke cloud
				spawnImpactCloud(targetX, targetY);
				
				// Spawn oneko immediately at landing position
				let cat: any = null;
				if (Oneko) {
					cat = new Oneko({
						x: targetX + 15,
						y: targetY + 4,
						allowedIdleAnimations: ['sleeping'],
						idleAnimation: 'sleeping',
						skipAlertAnimation: true,
						idleTime: 192,
						idleAnimationFrame: 50,
						source: '/oneko.png'
					});
					
					// Lower cat z-index so smoke appears above and add cursor pointer
					cat.element.style.zIndex = '999999998';
					cat.element.style.pointerEvents = 'auto';
					cat.element.style.cursor = 'pointer';
					
					let isAwake = false;
					let isSitting = false;
					let sitTimer: number | null = null;
					
					const startSleeping = () => {
						cat.allowedIdleAnimations = ['sleeping'];
						cat.idleAnimation = 'sleeping';
						cat.idleTime = 192;
						cat.idleAnimationFrame = 50;
						isAwake = false;
					};
					
					const wakeUp = () => {
						isAwake = true;
						isSitting = false;
						if (sitTimer) clearTimeout(sitTimer);
						cat.allowedIdleAnimations = ['sleeping', 'scratchSelf', 'scratchWallN', 'scratchWallE', 'scratchWallS', 'scratchWallW'];
						cat.idleAnimation = null;
						cat.idleTime = 0;
					};
					
					const sit = () => {
						isSitting = true;
						cat.setTarget(cat.x, cat.y);
						
						// Fall asleep after 5 seconds of sitting
						if (sitTimer) clearTimeout(sitTimer);
						sitTimer = window.setTimeout(() => {
							startSleeping();
						}, 5000);
					};
					
					const handleMouseMove = (e: MouseEvent) => {
						if (isAwake && !isSitting) {
							cat.setTarget(e.clientX, e.clientY);
						}
					};
					
					const handleClick = (e: MouseEvent) => {
						const catRect = cat.element.getBoundingClientRect();
						const clickOnCat = e.clientX >= catRect.left && 
							e.clientX <= catRect.right && 
							e.clientY >= catRect.top && 
							e.clientY <= catRect.bottom;
						
						if (clickOnCat) {
							if (isSitting || !isAwake) {
								wakeUp();
							} else {
								sit();
							}
						} else if (isAwake && !isSitting) {
							cat.setTarget(e.clientX, e.clientY);
						} else if (!isAwake) {
							wakeUp();
							cat.setTarget(e.clientX, e.clientY);
						}
					};
					
					window.addEventListener('mousemove', handleMouseMove);
					window.addEventListener('click', handleClick);
				}
				
				// Shake screen (pass cat element for debugging)
				shakeScreen(cat?.element);
				
				// Fade out hole and re-enable scrolling
				setTimeout(() => {
					(async () => {
						const gsap = await import('gsap');
						const fadeState = { opacity: 1 };
						
						gsap.default.to(fadeState, {
							opacity: 0,
							duration: 1.5,
							delay: 0.5,
							ease: 'power1.out',
							onUpdate: () => {
								holeOpacity = fadeState.opacity;
							},
							onComplete: () => {
								showHole = false;
							}
						});
					})();
					
					// Re-enable scrolling
					document.body.style.overflow = '';
				}, 1000);
			}
		});
	};

	export function trigger() {
		isFlashing = true;
		setTimeout(() => {
			isFlashing = false;
		}, 1000);

		const position = calculateRandomPortalPosition();
		animateAsteroid(position.x, position.y);
	}
</script>

<style>
	@keyframes flash {
		0% { opacity: 1; }
		100% { opacity: 0; }
	}
	.flash-overlay {
		animation: flash 1000ms ease-out forwards;
	}
	@keyframes flashLanding {
		0% { opacity: 0.35; }
		100% { opacity: 0; }
	}
	.flash-landing-overlay {
		animation: flashLanding 2500ms ease-out forwards;
	}
</style>

<div class="fixed inset-0 pointer-events-none" style="z-index: 999999999; transform: {shakeTransform};">
	{#each smokeParticles as particle (particle.id)}
		<img
			src="/smoke-{particle.image}.png"
			alt=""
			class="absolute pointer-events-none"
			style="left: {particle.x}px; top: {particle.y}px; transform: translate(-50%, -50%) rotate({particle.rotation}deg); opacity: {particle.opacity}; width: {particle.size}rem; height: {particle.size}rem; image-rendering: pixelated;"
		/>
	{/each}
</div>

{#if isFlashing}
	<div class="fixed inset-0 bg-white pointer-events-none flash-overlay" style="z-index: 2147483647;"></div>
{/if}

{#if isLandingFlash}
	<div class="fixed inset-0 bg-cream-800 pointer-events-none flash-landing-overlay" style="z-index: 2147483647;"></div>
{/if}

{#if showAsteroid && asteroidPosition}
	<img
		src="/asteroid.png"
		alt=""
		class="fixed z-100 pointer-events-none"
		style="left: {asteroidPosition.x}px; top: {asteroidPosition.y}px; transform: translate(-50%, -50%) rotate({asteroidPosition.rotation}deg) {shakeTransform}; width: 1.5rem; height: 1.5rem; image-rendering: pixelated;"
	/>
{/if}

{#if showHole && holePosition}
	<img
		src="/hole.png"
		alt=""
		class="fixed z-100 pointer-events-none"
		style="left: {holePosition.x}px; top: {holePosition.y}px; transform: translate(-50%, -50%) {shakeTransform}; width: 1.9rem; height: 0.8rem; opacity: {holeOpacity}; image-rendering: pixelated;"
	/>
{/if}
