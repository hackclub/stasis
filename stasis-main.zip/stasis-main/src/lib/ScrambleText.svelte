<script lang="ts">
	import { onMount, onDestroy } from 'svelte';
	import { gsap } from 'gsap';

	interface Props {
		text?: string;
		duration?: number;
		charset?: string;
		scrambleSpeed?: number;
		staggerMax?: number;
		delayMax?: number;
		threshold?: number;
		triggerOnce?: boolean;
		class?: string;
		as?: string;
	}

	let {
		text = '',
		duration = 1.2,
		charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*',
		scrambleSpeed = 30,
		staggerMax = 0.6,
		delayMax = 0.4,
		threshold = 0.2,
		triggerOnce = true,
		class: className = '',
		as = 'span'
	}: Props = $props();

	interface CharData {
		original: string;
		current: string;
		isStatic: boolean;
		locked: boolean;
		lockTime: number;
	}

	let characters: CharData[] = $state([]);
	let container: HTMLElement;
	let observer: IntersectionObserver;
	let isAnimating = false;
	let animationStartTime = 0;
	let tickerCallback: () => void;

	function initializeCharacters() {
		const chars = text.split('');
		characters = chars.map((char, index) => {
			const isStatic = char === ' ' || /[^\w]/.test(char);
			const lockTime = isStatic ? 0 : Math.random() * delayMax + (index / chars.length) * staggerMax;
			
			return {
				original: char,
				current: isStatic ? char : getRandomChar(),
				isStatic,
				locked: isStatic,
				lockTime: lockTime * 1000
			};
		});
	}

	function getRandomChar(): string {
		return charset[Math.floor(Math.random() * charset.length)];
	}

	function scrambleChars() {
		if (!isAnimating) return;

		const elapsed = Date.now() - animationStartTime;

		let allLocked = true;
		for (let i = 0; i < characters.length; i++) {
			const char = characters[i];
			
			if (char.isStatic) continue;

			if (!char.locked) {
				if (elapsed >= char.lockTime) {
					char.locked = true;
					char.current = char.original;
				} else {
					char.current = getRandomChar();
					allLocked = false;
				}
			}
		}

		if (allLocked && elapsed >= duration * 1000) {
			stopAnimation();
		}
	}

	function startAnimation() {
		if (isAnimating) return;
		
		isAnimating = true;
		animationStartTime = Date.now();
		
		tickerCallback = () => {
			scrambleChars();
		};
		
		gsap.ticker.add(tickerCallback);
	}

	function stopAnimation() {
		isAnimating = false;
		if (tickerCallback) {
			gsap.ticker.remove(tickerCallback);
		}
	}

	onMount(() => {
		initializeCharacters();

		observer = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						startAnimation();
						if (triggerOnce) {
							observer.disconnect();
						}
					}
				});
			},
			{ threshold }
		);

		if (container) {
			observer.observe(container);
		}
	});

	onDestroy(() => {
		stopAnimation();
		observer?.disconnect();
	});
</script>

<svelte:element this={as} bind:this={container} class={className}>
	{#each characters as char}
		<span class="char">{char.current}</span>
	{/each}
</svelte:element>

<style>
	.char {
		display: inline-block;
	}
</style>
