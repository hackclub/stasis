<script lang="ts">
	import { onMount } from 'svelte';

	interface Props {
		mode?: 'corners' | 'border';
		cornerSize?: number;
		borderWidth?: number;
		offset?: number;
		color?: string;
		hoverColor?: string;
		magnetStrength?: number;
		activationDistance?: number;
		deactivationDistance?: number;
		hoverOffsetIncrease?: number;
	}

	let {
		mode = 'corners',
		cornerSize = 20,
		borderWidth = 3,
		offset = 6,
		color = `#ea745290`,
		hoverColor,
		magnetStrength = 0.1,
		activationDistance = 50,
		deactivationDistance = 60,
		hoverOffsetIncrease = 4,
	}: Props = $props();

	let containerRef: HTMLDivElement;
	let buttonRef: HTMLButtonElement | null = null;
	let translateX = $state(0);
	let translateY = $state(0);
	let isActive = $state(false);
	let currentOffset = $derived(isActive ? offset + hoverOffsetIncrease : offset);
	let currentColor = $derived(isActive && hoverColor ? hoverColor : color);

	const getDistanceToElement = (mouseX: number, mouseY: number, rect: DOMRect): number => {
		const closestX = Math.max(rect.left, Math.min(mouseX, rect.right));
		const closestY = Math.max(rect.top, Math.min(mouseY, rect.bottom));
		const deltaX = mouseX - closestX;
		const deltaY = mouseY - closestY;
		return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
	};

	onMount(() => {
		buttonRef = containerRef?.querySelector('button');

		const handleMouseMove = (e: MouseEvent) => {
			if (!containerRef) return;

			const rect = containerRef.getBoundingClientRect();
			const centerX = rect.left + rect.width / 2;
			const centerY = rect.top + rect.height / 2;

			const distance = getDistanceToElement(e.clientX, e.clientY, rect);

			if (!isActive && distance <= activationDistance) {
				isActive = true;
			} else if (isActive && distance > deactivationDistance) {
				isActive = false;
				translateX = 0;
				translateY = 0;
				return;
			}

			if (isActive) {
				const offsetX = e.clientX - centerX;
				const offsetY = e.clientY - centerY;

				translateX = offsetX * magnetStrength;
				translateY = offsetY * magnetStrength;
			}
		};

		window.addEventListener('mousemove', handleMouseMove);

		return () => {
			window.removeEventListener('mousemove', handleMouseMove);
		};
	});

	function handleHitboxClick() {
		if (buttonRef) {
			buttonRef.click();
		}
	}
</script>

<div bind:this={containerRef} class="magnetic-corners-wrapper" class:active={isActive}>
	<slot />
	{#if isActive}
		<div 
			class="magnetic-hitbox" 
			style="--activation: {activationDistance}px"
			onclick={handleHitboxClick}
		></div>
	{/if}
	{#if mode === 'border'}
		<div
			class="border-box"
			style="--border: {borderWidth}px; --offset: {currentOffset}px; --color: {currentColor}; transform: translate({translateX}px, {translateY}px)"
		></div>
	{:else}
		<div
			class="corner corner-tl"
			style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {currentOffset}px; --color: {currentColor}; transform: translate({translateX}px, {translateY}px)"
		></div>
		<div
			class="corner corner-tr"
			style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {currentOffset}px; --color: {currentColor}; transform: translate({translateX}px, {translateY}px)"
		></div>
		<div
			class="corner corner-br"
			style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {currentOffset}px; --color: {currentColor}; transform: translate({translateX}px, {translateY}px)"
		></div>
		<div
			class="corner corner-bl"
			style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {currentOffset}px; --color: {currentColor}; transform: translate({translateX}px, {translateY}px)"
		></div>
	{/if}
</div>

<style>
	.magnetic-corners-wrapper {
		position: relative;
		display: inline-block;
	}

	.magnetic-corners-wrapper.active :global(button) {
		background-color: #e0643e !important;
	}

	.magnetic-corners-wrapper.active :global(button::before) {
		border-color: #e89161 !important;
		inset: -0.5rem !important;
	}

	.magnetic-hitbox {
		position: absolute;
		top: calc(-1 * var(--activation));
		left: calc(-1 * var(--activation));
		right: calc(-1 * var(--activation));
		bottom: calc(-1 * var(--activation));
		cursor: pointer;
		z-index: 1;
	}

	.corner {
		position: absolute;
		width: var(--size);
		height: var(--size);
		border: var(--border) solid var(--color);
		pointer-events: none;
		transition: 
			transform 0.15s ease-out,
			top 0.2s ease-out,
			left 0.2s ease-out,
			right 0.2s ease-out,
			bottom 0.2s ease-out;
		z-index: 2;
	}

	.corner-tl {
		top: calc(-1 * var(--offset));
		left: calc(-1 * var(--offset));
		border-right: none;
		border-bottom: none;
	}

	.corner-tr {
		top: calc(-1 * var(--offset));
		right: calc(-1 * var(--offset));
		border-left: none;
		border-bottom: none;
	}

	.corner-br {
		bottom: calc(-1 * var(--offset));
		right: calc(-1 * var(--offset));
		border-left: none;
		border-top: none;
	}

	.corner-bl {
		bottom: calc(-1 * var(--offset));
		left: calc(-1 * var(--offset));
		border-right: none;
		border-top: none;
	}

	.border-box {
		position: absolute;
		top: calc(-1 * var(--offset));
		left: calc(-1 * var(--offset));
		right: calc(-1 * var(--offset));
		bottom: calc(-1 * var(--offset));
		border: var(--border) solid var(--color);
		pointer-events: none;
		transition: 
			transform 0.15s ease-out,
			top 0.2s ease-out,
			left 0.2s ease-out,
			right 0.2s ease-out,
			bottom 0.2s ease-out;
		z-index: 2;
	}
</style>
