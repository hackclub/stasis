<script lang="ts">
	import { onMount } from 'svelte';
	import gsap from 'gsap';

	let container: HTMLButtonElement;
	let isHovered = $state(false);
	
	type Shape = {
		type: 'circle' | 'square' | 'triangle';
		x: number;
		y: number;
		size: number;
		rotation: number;
		opacity: number;
		element?: HTMLElement;
	};

	function generateShapes(): Shape[] {
		const shapes: Shape[] = [];
		const types: Array<'circle' | 'square' | 'triangle'> = ['circle', 'square', 'triangle'];
		const gridSize = 8;
		const cellSize = 100 / gridSize;
		const minSpacing = 12;
		
		// Define exclusion zone for "GUIDE" text (center area)
		const excludeLeft = 30;
		const excludeRight = 70;
		const excludeTop = 35;
		const excludeBottom = 65;
		
		for (let i = 0; i < gridSize; i++) {
			for (let j = 0; j < gridSize; j++) {
				const cellX = i * cellSize;
				const cellY = j * cellSize;
				
				// Check if in exclusion zone
				const isInExclusionZone = 
					cellX > excludeLeft - cellSize && 
					cellX < excludeRight && 
					cellY > excludeTop - cellSize && 
					cellY < excludeBottom;
				
				if (isInExclusionZone) continue;
				
				// Random chance to place a shape (not every cell)
				if (Math.random() > 0.6) continue;
				
				// Add random offset within cell
				const x = cellX + cellSize * 0.5 + (Math.random() - 0.5) * cellSize * 0.4;
				const y = cellY + cellSize * 0.5 + (Math.random() - 0.5) * cellSize * 0.4;
				
				const baseSize = 7;
				const sizeVariation = (Math.random() - 0.5) * 3;
				
				shapes.push({
					type: types[Math.floor(Math.random() * types.length)],
					x: Math.max(2, Math.min(98, x)),
					y: Math.max(2, Math.min(98, y)),
					size: baseSize + sizeVariation,
					rotation: Math.random() * 360,
					opacity: 0.3 + Math.random() * 0.2
				});
			}
		}
		
		return shapes;
	}

	const shapes = generateShapes();

	onMount(() => {
		// Set initial position of all shapes (off-screen)
		shapes.forEach((shape) => {
			if (shape.element && container) {
				const buttonWidth = container.offsetWidth;
				const buttonHeight = container.offsetHeight;
				const targetX = (shape.x / 100) * buttonWidth;
				const targetY = (shape.y / 100) * buttonHeight;
				
				const angle = Math.random() * Math.PI * 2;
				const distance = 300;
				const startX = targetX + Math.cos(angle) * distance;
				const startY = targetY + Math.sin(angle) * distance;

				gsap.set(shape.element, {
					x: startX,
					y: startY,
					opacity: 0,
					rotation: shape.rotation + (Math.random() - 0.5) * 360
				});
			}
		});
	});

	function handleMouseEnter() {
		isHovered = true;

		shapes.forEach((shape, i) => {
			if (shape.element && container) {
				const buttonWidth = container.offsetWidth;
				const buttonHeight = container.offsetHeight;
				const targetX = (shape.x / 100) * buttonWidth;
				const targetY = (shape.y / 100) * buttonHeight;
				
				gsap.to(shape.element, {
					x: targetX,
					y: targetY,
					opacity: shape.opacity,
					rotation: shape.rotation,
					duration: 0.5 + Math.random() * 0.3,
					delay: Math.random() * 0.2,
					ease: 'power2.out'
				});
			}
		});
	}

	function handleMouseLeave() {
		isHovered = false;

		shapes.forEach((shape) => {
			if (shape.element && container) {
				const buttonWidth = container.offsetWidth;
				const buttonHeight = container.offsetHeight;
				const targetX = (shape.x / 100) * buttonWidth;
				const targetY = (shape.y / 100) * buttonHeight;
				
				const angle = Math.random() * Math.PI * 2;
				const distance = 300;
				const endX = targetX + Math.cos(angle) * distance;
				const endY = targetY + Math.sin(angle) * distance;

				gsap.to(shape.element, {
					x: endX,
					y: endY,
					opacity: 0,
					rotation: shape.rotation + (Math.random() - 0.5) * 360,
					duration: 0.5 + Math.random() * 0.2,
					delay: Math.random() * 0.1,
					ease: 'power2.in'
				});
			}
		});
	}
</script>

<button
	bind:this={container}
	class="relative w-full cursor-pointer overflow-hidden py-8 text-2xl text-cream-50"
	onmouseenter={handleMouseEnter}
	onmouseleave={handleMouseLeave}
>
	<div class="pointer-events-none absolute inset-0">
		{#each shapes as shape}
			<div
				bind:this={shape.element}
				class="absolute"
				style="left: 0; top: 0; will-change: transform, opacity;"
			>
				{#if shape.type === 'circle'}
					<div
						class="rounded-full bg-cream-500"
						style="width: {shape.size}px; height: {shape.size}px;"
					></div>
				{:else if shape.type === 'square'}
					<div class="bg-cream-500" style="width: {shape.size}px; height: {shape.size}px;"></div>
				{:else if shape.type === 'triangle'}
					<div
						class="bg-cream-500"
						style="width: {shape.size}px; height: {shape.size}px; clip-path: polygon(50% 0%, 0% 100%, 100% 100%);"
					></div>
				{/if}
			</div>
		{/each}
	</div>

	<span class="relative z-10">GUIDE</span>
</button>
