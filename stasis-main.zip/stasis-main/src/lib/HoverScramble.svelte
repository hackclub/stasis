<script lang="ts">
	import { onMount } from 'svelte';

	interface TextSegment {
		text: string;
		class?: string;
	}

	interface Props {
		segments: TextSegment[];
		charset?: string;
		iterations?: number;
		speed?: number;
		rippleRadius?: number;
		initialScramble?: boolean;
		initialDuration?: number;
		initialStagger?: number;
		initialDelay?: number;
		continuousScramble?: boolean;
		continuousSpeed?: number;
		continuousCharset?: string;
		class?: string;
	}

	let {
		segments,
		charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*',
		iterations = 7,
		speed = 10,
		rippleRadius = 1,
		initialScramble = false,
		initialDuration = 1.2,
		initialStagger = 0.6,
		initialDelay = 0.4,
		continuousScramble = false,
		continuousSpeed = 150,
		continuousCharset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*',
		class: className = ''
	}: Props = $props();

	interface CharState {
		original: string;
		current: string;
		animating: boolean;
		iteration: number;
		intervalId: number | null;
		segmentClass: string;
	}

	function getRandomChar(customCharset?: string): string {
		const charsetToUse = customCharset || charset;
		return charsetToUse[Math.floor(Math.random() * charsetToUse.length)];
	}

	function initializeCharacters(): CharState[] {
		const chars: CharState[] = [];
		segments.forEach((segment) => {
			segment.text.split('').forEach((char) => {
				chars.push({
					original: char,
					current: char,
					animating: false,
					iteration: 0,
					intervalId: null,
					segmentClass: segment.class || ''
				});
			});
		});
		return chars;
	}

	let characters: CharState[] = $state(initializeCharacters());

	function scrambleChar(index: number) {
		const char = characters[index];
		if (char.animating || char.original === ' ' || /[^\w]/.test(char.original)) return;

		char.animating = true;
		char.iteration = 0;

		const nextIteration = () => {
			if (char.iteration < iterations) {
				char.current = getRandomChar();
				char.iteration++;
				
				const delay = speed * Math.pow(1.2, char.iteration);
				char.intervalId = window.setTimeout(nextIteration, delay);
			} else {
				char.current = char.original;
				char.animating = false;
				char.intervalId = null;
			}
		};

		nextIteration();
	}

	function handleHover(index: number) {
		scrambleChar(index);
		
		for (let i = Math.max(0, index - rippleRadius); i <= Math.min(characters.length - 1, index + rippleRadius); i++) {
			if (i !== index) {
				const distance = Math.abs(i - index);
				setTimeout(() => scrambleChar(i), distance * 15);
			}
		}
	}

	onMount(() => {
		if (initialScramble) {
			const animationStartTime = Date.now();
			
			const scrambleInitial = () => {
				const elapsed = Date.now() - animationStartTime;
				
				let allLocked = true;
				for (let i = 0; i < characters.length; i++) {
					const char = characters[i];
					
					if (char.original === ' ' || /[^\w]/.test(char.original)) continue;
					
					const lockTime = Math.random() * initialDelay * 1000 + (i / characters.length) * initialStagger * 1000;
					
					if (elapsed >= lockTime) {
						char.current = char.original;
					} else {
						char.current = getRandomChar();
						allLocked = false;
					}
				}
				
				if (!allLocked && elapsed < initialDuration * 1000) {
					requestAnimationFrame(scrambleInitial);
				}
			};
			
			requestAnimationFrame(scrambleInitial);
		}

		let continuousInterval: number | null = null;
		if (continuousScramble) {
			continuousInterval = window.setInterval(() => {
				for (let i = 0; i < characters.length; i++) {
					const char = characters[i];
					
					if (char.animating || char.original === ' ' || /[^\w]/.test(char.original)) continue;
					if (char.segmentClass.includes('text-cream-800')) continue;
					
					if (Math.random() < 0.3) {
						char.current = getRandomChar(continuousCharset);
					}
				}
			}, continuousSpeed);
		}

		return () => {
			characters.forEach((char) => {
				if (char.intervalId !== null) {
					clearTimeout(char.intervalId);
				}
			});
			if (continuousInterval !== null) {
				clearInterval(continuousInterval);
			}
		};
	});
</script>

<div class={className}>
	{#each characters as char, i}
		{#if char.original === ' '}
			<span class={char.segmentClass}>{char.current}</span>
		{:else}
			<span
				class="hover-char {char.segmentClass}"
				onmouseenter={() => handleHover(i)}
			>
				{char.current}
			</span>
		{/if}
	{/each}
</div>

<style>
	.hover-char {
		cursor: default;
	}
</style>
