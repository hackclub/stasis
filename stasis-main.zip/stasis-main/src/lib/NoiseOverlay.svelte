<script lang="ts">
	import { onMount } from 'svelte';

	let canvas: HTMLCanvasElement;

	onMount(() => {
		const ctx = canvas.getContext('2d');
		if (!ctx) return;

		const resize = () => {
			canvas.width = window.innerWidth;
			canvas.height = window.innerHeight;
		};

		const generateNoise = () => {
			const imageData = ctx.createImageData(canvas.width, canvas.height);
			const data = imageData.data;

			for (let i = 0; i < data.length; i += 4) {
				const value = Math.random() * 255;
				data[i] = value;
				data[i + 1] = value;
				data[i + 2] = value;
				data[i + 3] = 51;
			}

			ctx.putImageData(imageData, 0, 0);
		};

		resize();
		window.addEventListener('resize', resize);

		const interval = setInterval(generateNoise, 100);

		return () => {
			window.removeEventListener('resize', resize);
			clearInterval(interval);
		};
	});
</script>

<canvas bind:this={canvas} class="noise-overlay"></canvas>

<style>
	.noise-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		pointer-events: none;
		z-index: 9999;
		opacity: 0.2;
	}
</style>
