<script lang="ts">
	type Orientation = 'horizontal' | 'vertical';
	
	export let orientation: Orientation = 'horizontal';
	
	const offset = Math.random() * 1202;
</script>

<div 
	class="absolute -z-2 dotted-line {orientation} {orientation === 'vertical' ? 'w-px h-full' : 'h-px w-full'} z-50"
	style="--offset: {offset}px"
></div>

<style>
	.dotted-line {
		background-repeat: repeat;
		image-rendering: pixelated;
		filter: brightness(98%) saturate(95%);
	}
	
	.dotted-line.horizontal {
		background-image: url('/dotted-line.svg');
		background-position: var(--offset) 0;
	}
	
	.dotted-line.vertical {
		background-image: url('/dotted-line-vertical.svg');
	}
</style>
