<script lang="ts">
	interface Props {
		inset?: string;
	}

	let { inset = '3rem' }: Props = $props();
	
	let mouseX = $state(-1000);
	let mouseY = $state(0);
	let container: HTMLElement;
	
	function handleMouseMove(e: MouseEvent) {
		if (!container) return;
		const rect = container.getBoundingClientRect();
		mouseX = e.clientX - rect.left;
		mouseY = e.clientY - rect.top;
	}
</script>

<svelte:window onmousemove={handleMouseMove} />

<footer class="pointer-events-auto pt-16 relative">
	<div class="pointer-events-auto pb-12 px-4 md:pl-[{inset}] md:pr-[{inset}]">
		<div class="mx-auto max-w-md w-max">
			<p class="font-mono text-xs md:text-sm">Made with <span class="bg-brand-500 text-cream-100">&lt;3</span> by teenagers, for teenagers</p>
			<div class="mt-2">
				<a href="https://hackclub.com" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Hack Club</a>
				<span>・</span>
				<a href="https://hackclub.com/slack" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Slack</a>
				<span>・</span>
				<a href="https://hackclub.com/clubs" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Clubs</a>
				<span>・</span>
				<a href="https://hackclub.com/hackathons" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100"
					>Hackathons</a
				>
			</div>
		</div>
	</div>

	<div bind:this={container} class="md:opacity-10 relative mx-auto w-full md:w-[calc(100%-6rem)] pointer-events-none translate-y-0.5">
		<img src="/stasis-text.svg" alt="" class="w-full absolute md:hidden">
		<img src="/stasis-text-stroke.svg" alt="" class="w-full opacity-50">
		<img 
			src="/stasis-text.svg" 
			alt="" 
			class="absolute top-0 left-0 w-full"
			style="
				mask-image: radial-gradient(circle 400px at {mouseX}px {mouseY}px, #383734 0%, transparent 100%);
				-webkit-mask-image: radial-gradient(circle 400px at {mouseX}px {mouseY}px, #383734 0%, transparent 100%);
			"
		>
	</div>
	<div class="md:hidden w-full h-12 bg-cream-800"></div>
</footer>
