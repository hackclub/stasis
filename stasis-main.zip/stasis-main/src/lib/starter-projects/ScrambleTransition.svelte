<script lang="ts">
	import { onDestroy } from 'svelte';
	import { gsap } from 'gsap';

	interface Props {
		text: string;
		duration?: number;
		charset?: string;
		scrambleSpeed?: number;
		class?: string;
	}

	let {
		text = $bindable(''),
		duration = 0.6,
		charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*!?.,;:',
		scrambleSpeed = 30,
		class: className = ''
	}: Props = $props();

	interface CharData {
		current: string;
		locked: boolean;
		lockTime: number;
	}

	let characters: CharData[] = $state([]);
	let displayText = $derived(characters.map(c => c.current).join(''));
	let isAnimating = false;
	let animationStartTime = 0;
	let tickerCallback: (() => void) | null = null;
	let previousText = '';
	let targetText = '';

	function getRandomChar(): string {
		return charset[Math.floor(Math.random() * charset.length)];
	}

	function easeOutCubic(t: number): number {
		return 1 - Math.pow(1 - t, 3);
	}

	function initializeTransition(from: string, to: string) {
		const maxLength = Math.max(from.length, to.length);
		
		characters = Array.from({ length: maxLength }, (_, i) => {
			const delay = (i / maxLength) * 0.4;
			const lockTime = delay + duration * 0.3;
			
			const fromChar = i < from.length ? from[i] : '';
			
			return {
				current: fromChar === ' ' ? getRandomChar() : fromChar,
				locked: false,
				lockTime: lockTime * 1000
			};
		});
	}

	function scrambleChars() {
		if (!isAnimating) return;

		const elapsed = Date.now() - animationStartTime;
		const progress = Math.min(elapsed / (duration * 1000), 1);
		const easedProgress = easeOutCubic(progress);
		
		const currentLength = Math.round(
			previousText.length + (targetText.length - previousText.length) * easedProgress
		);

		let allLocked = true;
		for (let i = 0; i < characters.length; i++) {
			const char = characters[i];
			
			if (i >= currentLength) {
				char.current = '';
				char.locked = false;
				continue;
			}

			if (!char.locked) {
				if (elapsed >= char.lockTime) {
					char.locked = true;
					char.current = i < targetText.length ? targetText[i] : '';
				} else {
					char.current = getRandomChar();
					allLocked = false;
				}
			}
		}

		if (allLocked && progress >= 1) {
			stopAnimation();
			characters = targetText.split('').map(c => ({
				current: c,
				locked: true,
				lockTime: 0
			}));
		}
	}

	function startAnimation(from: string, to: string) {
		if (from === to) return;
		
		stopAnimation();
		
		previousText = from;
		targetText = to;
		isAnimating = true;
		animationStartTime = Date.now();
		
		initializeTransition(from, to);
		
		tickerCallback = () => {
			scrambleChars();
		};
		
		gsap.ticker.add(tickerCallback);
	}

	function stopAnimation() {
		isAnimating = false;
		if (tickerCallback) {
			gsap.ticker.remove(tickerCallback);
			tickerCallback = null;
		}
	}

	$effect(() => {
		const currentDisplay = displayText;
		if (text !== currentDisplay && !isAnimating) {
			startAnimation(currentDisplay || '', text);
		}
	});

	onDestroy(() => {
		stopAnimation();
	});
</script>

<span class="scramble-wrap {className}">
	{displayText || text}
</span>

<style>
	.scramble-wrap {
		display: inline;
		word-wrap: break-word;
		overflow-wrap: break-word;
		white-space: normal;
		max-width: 100%;
	}
</style>
