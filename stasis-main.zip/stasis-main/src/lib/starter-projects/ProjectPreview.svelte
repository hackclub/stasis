<script lang="ts">
	interface Props {
		project: any;
		onclick?: () => void;
		selected?: boolean;
	}

	let { project, onclick, selected = false }: Props = $props();
</script>

<style>
	@keyframes selected-bounce {
		0% { transform: scale(1) rotate(0deg); }
		20% { transform: scale(0.97) rotate(0deg); }
		100% { transform: scale(1.05) rotate(1.5deg); }
	}

	img {
		transform: scale(1) rotate(0deg);
		transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
	}

	img.selected {
		animation: selected-bounce 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
		transform: scale(1.05) rotate(1.5deg);
	}
</style>

<button class="aspect-square bg-cream-950 relative select-none w-full cursor-pointer overflow-hidden" data-project-card="true" onclick={onclick}>
    <img src="/projects/{project.id}-gray.png" alt="" class="w-full h-full inset-0" class:selected draggable="false">
</button>