<script lang="ts">
	import { onMount } from 'svelte';
	import gsap from 'gsap';

	interface Props {
		gridEl: HTMLDivElement | undefined;
		selectedIndex: number | null;
	}

	let { gridEl, selectedIndex }: Props = $props();

	let cornerTL: HTMLDivElement;
	let cornerTR: HTMLDivElement;
	let cornerBR: HTMLDivElement;
	let cornerBL: HTMLDivElement;
	let currentHoveredCard = $state<HTMLElement | null>(null);
	let isFirstHover = true;
	let breatheOffset = $state(0);
	let basePositions = $state({ tl: { x: 0, y: 0 }, tr: { x: 0, y: 0 }, br: { x: 0, y: 0 }, bl: { x: 0, y: 0 } });
	let breatheTimeline: gsap.core.Timeline;
	let isMouseDown = $state(false);
	let previousSelectedIndex: number | null = null;

	const CORNER_SIZE = 20;
	const BORDER_WIDTH = 3;
	const INSET = 8;
	const MAGNET_STRENGTH = 0.15;
	const BREATHE_AMOUNT = 6;
	const INITIAL_OFFSET = CORNER_SIZE + 5;

	let previousHoveredCard: HTMLElement | null = null;
	let lastMovementCard: HTMLElement | null = null;

	$effect(() => {
		if (currentHoveredCard !== previousHoveredCard) {
			if (previousHoveredCard) {
				previousHoveredCard.classList.remove('hovered-project');
				previousHoveredCard.classList.remove('active-project');
			}
			
			if (currentHoveredCard) {
				currentHoveredCard.classList.add('hovered-project');
			}

			previousHoveredCard = currentHoveredCard;
		}
	});

	$effect(() => {
		if (!gridEl) return;
		
		const cards = gridEl.querySelectorAll('[data-project-card]');
		
		if (previousSelectedIndex !== null && previousSelectedIndex < cards.length) {
			cards[previousSelectedIndex].classList.remove('selected-project');
		}
		
		if (selectedIndex !== null && selectedIndex < cards.length) {
			cards[selectedIndex].classList.add('selected-project');
		}
		
		previousSelectedIndex = selectedIndex;
	});

	$effect(() => {
		if (isMouseDown && currentHoveredCard) {
			currentHoveredCard.classList.add('active-project');

			const rect = currentHoveredCard.getBoundingClientRect();
			const gridRect = gridEl?.getBoundingClientRect();
			if (!gridRect) return;

			const relativeTop = rect.top - gridRect.top + (gridEl?.scrollTop || 0);
			const relativeLeft = rect.left - gridRect.left + (gridEl?.scrollLeft || 0);
			const activeInset = INSET + 12;

			// Kill any ongoing animations on basePositions to prevent conflicts
			gsap.killTweensOf(basePositions.tl);
			gsap.killTweensOf(basePositions.tr);
			gsap.killTweensOf(basePositions.br);
			gsap.killTweensOf(basePositions.bl);

			gsap.to(basePositions.tl, {
				x: relativeLeft + activeInset,
				y: relativeTop + activeInset,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.tr, {
				x: relativeLeft + rect.width - activeInset - CORNER_SIZE,
				y: relativeTop + activeInset,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.br, {
				x: relativeLeft + rect.width - activeInset - CORNER_SIZE,
				y: relativeTop + rect.height - activeInset - CORNER_SIZE,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.bl, {
				x: relativeLeft + activeInset,
				y: relativeTop + rect.height - activeInset - CORNER_SIZE,
				duration: 0.15,
				ease: 'power2.out',
			});
		} else if (currentHoveredCard) {
			currentHoveredCard.classList.remove('active-project');
			
			const rect = currentHoveredCard.getBoundingClientRect();
			const gridRect = gridEl?.getBoundingClientRect();
			if (!gridRect) return;

			const relativeTop = rect.top - gridRect.top + (gridEl?.scrollTop || 0);
			const relativeLeft = rect.left - gridRect.left + (gridEl?.scrollLeft || 0);

			// Kill any ongoing animations on basePositions
			gsap.killTweensOf(basePositions.tl);
			gsap.killTweensOf(basePositions.tr);
			gsap.killTweensOf(basePositions.br);
			gsap.killTweensOf(basePositions.bl);

			gsap.to(basePositions.tl, {
				x: relativeLeft + INSET,
				y: relativeTop + INSET,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.tr, {
				x: relativeLeft + rect.width - INSET - CORNER_SIZE,
				y: relativeTop + INSET,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.br, {
				x: relativeLeft + rect.width - INSET - CORNER_SIZE,
				y: relativeTop + rect.height - INSET - CORNER_SIZE,
				duration: 0.15,
				ease: 'power2.out',
			});

			gsap.to(basePositions.bl, {
				x: relativeLeft + INSET,
				y: relativeTop + rect.height - INSET - CORNER_SIZE,
				duration: 0.15,
				ease: 'power2.out',
			});
		}
	});

	$effect(() => {
		if (!gridEl || !cornerTL) return;

		gsap.set([cornerTL, cornerTR, cornerBR, cornerBL], {
			opacity: 1,
			x: -INITIAL_OFFSET,
			y: -INITIAL_OFFSET,
		});

		basePositions.tl = { x: -INITIAL_OFFSET, y: -INITIAL_OFFSET };
		basePositions.tr = { x: -INITIAL_OFFSET, y: -INITIAL_OFFSET };
		basePositions.br = { x: -INITIAL_OFFSET, y: -INITIAL_OFFSET };
		basePositions.bl = { x: -INITIAL_OFFSET, y: -INITIAL_OFFSET };

		breatheTimeline = gsap.timeline({ repeat: -1, yoyo: true });
		breatheTimeline.to(
			{ value: 0 },
			{
				value: BREATHE_AMOUNT,
				duration: 1.0,
				ease: 'sine.inOut',
				onUpdate: function() {
					breatheOffset = this.targets()[0].value;
					
					gsap.set(cornerTL, {
						x: basePositions.tl.x + breatheOffset,
						y: basePositions.tl.y + breatheOffset,
					});
					
					gsap.set(cornerTR, {
						x: basePositions.tr.x - breatheOffset,
						y: basePositions.tr.y + breatheOffset,
					});
					
					gsap.set(cornerBR, {
						x: basePositions.br.x - breatheOffset,
						y: basePositions.br.y - breatheOffset,
					});
					
					gsap.set(cornerBL, {
						x: basePositions.bl.x + breatheOffset,
						y: basePositions.bl.y - breatheOffset,
					});
				}
			}
		);

		const findNearestCard = (x: number, y: number) => {
			const cards = gridEl!.querySelectorAll('[data-project-card]');
			let nearest = null;
			let minDist = Infinity;

			cards.forEach((card) => {
				const rect = card.getBoundingClientRect();
				const cardCenterX = rect.left + rect.width / 2;
				const cardCenterY = rect.top + rect.height / 2;
				const dist = Math.hypot(x - cardCenterX, y - cardCenterY);
				
				if (dist < minDist) {
					minDist = dist;
					nearest = card as HTMLElement;
				}
			});

			return nearest;
		};

		const handleMouseMove = (e: MouseEvent) => {
			const gridRect = gridEl!.getBoundingClientRect();
			const mouseX = e.clientX - gridRect.left;
			const mouseY = e.clientY - gridRect.top;

			const isInGrid = e.clientX >= gridRect.left && e.clientX <= gridRect.right &&
							 e.clientY >= gridRect.top && e.clientY <= gridRect.bottom;

			if (isInGrid && !isMouseDown) {
				const nearestCard = findNearestCard(e.clientX, e.clientY);
				if (nearestCard && nearestCard !== currentHoveredCard) {
					currentHoveredCard = nearestCard;
				}
			} else if (!isInGrid) {
				if (currentHoveredCard) {
					currentHoveredCard = null;
				}
				
				// Always update positions when outside to follow cursor
				const padding = CORNER_SIZE + BREATHE_AMOUNT + 20;
				const mouseX = e.clientX - gridRect.left;
				const mouseY = e.clientY - gridRect.top;
				
				let targetX, targetY;

				// Clamp to ensure corners stay outside visible bounds
				if (mouseX < 0) {
					targetX = Math.min(mouseX, -padding);
				} else if (mouseX > gridRect.width) {
					targetX = Math.max(mouseX, gridRect.width + padding);
				} else {
					targetX = mouseX;
				}

				if (mouseY < 0) {
					targetY = Math.min(mouseY, -padding);
				} else if (mouseY > gridRect.height) {
					targetY = Math.max(mouseY, gridRect.height + padding);
				} else {
					targetY = mouseY;
				}

				// Animate smoothly but quickly to follow cursor
				gsap.to(basePositions.tl, { x: targetX, y: targetY, duration: 0.2, ease: 'power2.out', overwrite: true });
				gsap.to(basePositions.tr, { x: targetX, y: targetY, duration: 0.2, ease: 'power2.out', overwrite: true });
				gsap.to(basePositions.br, { x: targetX, y: targetY, duration: 0.2, ease: 'power2.out', overwrite: true });
				gsap.to(basePositions.bl, { x: targetX, y: targetY, duration: 0.2, ease: 'power2.out', overwrite: true });
			}

			if (currentHoveredCard) {
				if (currentHoveredCard !== lastMovementCard && !isMouseDown) {
					lastMovementCard = currentHoveredCard;
					const rect = currentHoveredCard.getBoundingClientRect();
					const relativeTop = rect.top - gridRect.top + gridEl.scrollTop;
					const relativeLeft = rect.left - gridRect.left + gridEl.scrollLeft;

					gsap.to(basePositions.tl, {
						x: relativeLeft + INSET,
						y: relativeTop + INSET,
						duration: 0.6,
						ease: 'power2.out',
					});

					gsap.to(basePositions.tr, {
						x: relativeLeft + rect.width - INSET - CORNER_SIZE,
						y: relativeTop + INSET,
						duration: 0.6,
						ease: 'power2.out',
					});

					gsap.to(basePositions.br, {
						x: relativeLeft + rect.width - INSET - CORNER_SIZE,
						y: relativeTop + rect.height - INSET - CORNER_SIZE,
						duration: 0.6,
						ease: 'power2.out',
					});

					gsap.to(basePositions.bl, {
						x: relativeLeft + INSET,
						y: relativeTop + rect.height - INSET - CORNER_SIZE,
						duration: 0.6,
						ease: 'power2.out',
					});
				} else {
					const rect = currentHoveredCard.getBoundingClientRect();

					const centerX = rect.left + rect.width / 2;
					const centerY = rect.top + rect.height / 2;

					const offsetX = (e.clientX - centerX) * MAGNET_STRENGTH;
					const offsetY = (e.clientY - centerY) * MAGNET_STRENGTH;

					const relativeTop = rect.top - gridRect.top + gridEl.scrollTop;
					const relativeLeft = rect.left - gridRect.left + gridEl.scrollLeft;

					const tlTargetX = relativeLeft + INSET + offsetX;
					const tlTargetY = relativeTop + INSET + offsetY;
					const trTargetX = relativeLeft + rect.width - INSET - CORNER_SIZE + offsetX;
					const trTargetY = relativeTop + INSET + offsetY;
					const brTargetX = relativeLeft + rect.width - INSET - CORNER_SIZE + offsetX;
					const brTargetY = relativeTop + rect.height - INSET - CORNER_SIZE + offsetY;
					const blTargetX = relativeLeft + INSET + offsetX;
					const blTargetY = relativeTop + rect.height - INSET - CORNER_SIZE + offsetY;

					const distTL = Math.hypot(e.clientX - (rect.left + INSET), e.clientY - (rect.top + INSET));
					const distTR = Math.hypot(e.clientX - (rect.right - INSET), e.clientY - (rect.top + INSET));
					const distBR = Math.hypot(e.clientX - (rect.right - INSET), e.clientY - (rect.bottom - INSET));
					const distBL = Math.hypot(e.clientX - (rect.left + INSET), e.clientY - (rect.bottom - INSET));

					const baseDuration = 0.15;
					const dragFactor = 0.002;

					gsap.to(basePositions.tl, {
						x: tlTargetX,
						y: tlTargetY,
						duration: baseDuration + distTL * dragFactor,
						ease: 'power2.out',
					});

					gsap.to(basePositions.tr, {
						x: trTargetX,
						y: trTargetY,
						duration: baseDuration + distTR * dragFactor,
						ease: 'power2.out',
					});

					gsap.to(basePositions.br, {
						x: brTargetX,
						y: brTargetY,
						duration: baseDuration + distBR * dragFactor,
						ease: 'power2.out',
					});

					gsap.to(basePositions.bl, {
						x: blTargetX,
						y: blTargetY,
						duration: baseDuration + distBL * dragFactor,
						ease: 'power2.out',
					});
				}
			}
		};

		const handleFirstHover = (card: HTMLElement) => {
			const rect = card.getBoundingClientRect();
			const gridRect = gridEl!.getBoundingClientRect();

			const relativeTop = rect.top - gridRect.top + gridEl.scrollTop;
			const relativeLeft = rect.left - gridRect.left + gridEl.scrollLeft;
			const cardCenterX = relativeLeft + rect.width / 2;
			const cardCenterY = relativeTop + rect.height / 2;
			const gridCenterX = gridRect.width / 2;
			const gridCenterY = gridRect.height / 2;

			const fromTop = cardCenterY < gridCenterY;
			const fromLeft = cardCenterX < gridCenterX;

			const startX = fromLeft ? -INITIAL_OFFSET : gridRect.width + INITIAL_OFFSET;
			const startY = fromTop ? -INITIAL_OFFSET : gridRect.height + INITIAL_OFFSET;

			gsap.set(basePositions.tl, { x: startX, y: startY });
			gsap.set(basePositions.tr, { x: startX, y: startY });
			gsap.set(basePositions.br, { x: startX, y: startY });
			gsap.set(basePositions.bl, { x: startX, y: startY });

			gsap.to(basePositions.tl, {
				x: relativeLeft + INSET,
				y: relativeTop + INSET,
				duration: 0.6,
				ease: 'power2.out',
			});

			gsap.to(basePositions.tr, {
				x: relativeLeft + rect.width - INSET - CORNER_SIZE,
				y: relativeTop + INSET,
				duration: 0.6,
				ease: 'power2.out',
			});

			gsap.to(basePositions.br, {
				x: relativeLeft + rect.width - INSET - CORNER_SIZE,
				y: relativeTop + rect.height - INSET - CORNER_SIZE,
				duration: 0.6,
				ease: 'power2.out',
			});

			gsap.to(basePositions.bl, {
				x: relativeLeft + INSET,
				y: relativeTop + rect.height - INSET - CORNER_SIZE,
				duration: 0.6,
				ease: 'power2.out',
			});
		};

		let previousHoveredCardForAnimation: HTMLElement | null = null;

		$effect(() => {
			if (currentHoveredCard && currentHoveredCard !== previousHoveredCardForAnimation) {
				if (isFirstHover) {
					isFirstHover = false;
					handleFirstHover(currentHoveredCard);
				}
				
				if (breatheTimeline) {
					breatheTimeline.restart();
				}

				previousHoveredCardForAnimation = currentHoveredCard;
			}
		});

		const handleMouseDown = () => {
			isMouseDown = true;
			lastMovementCard = null;
		};

		const handleMouseUp = () => {
			isMouseDown = false;
			lastMovementCard = null;
		};

		window.addEventListener('mousemove', handleMouseMove);
		window.addEventListener('mousedown', handleMouseDown);
		window.addEventListener('mouseup', handleMouseUp);

		return () => {
			window.removeEventListener('mousemove', handleMouseMove);
			window.removeEventListener('mousedown', handleMouseDown);
			window.removeEventListener('mouseup', handleMouseUp);
			breatheTimeline.kill();
		};
	});
</script>

<div bind:this={cornerTL} class="corner corner-tl"></div>
<div bind:this={cornerTR} class="corner corner-tr"></div>
<div bind:this={cornerBR} class="corner corner-br"></div>
<div bind:this={cornerBL} class="corner corner-bl"></div>

<style>
	.corner {
		position: absolute;
		width: 20px;
		height: 20px;
		border: 3px solid #ea7452;
		pointer-events: none;
		z-index: 10;
		opacity: 0;
	}

	.corner-tl {
		border-right: none;
		border-bottom: none;
	}

	.corner-tr {
		border-left: none;
		border-bottom: none;
	}

	.corner-br {
		border-left: none;
		border-top: none;
	}

	.corner-bl {
		border-right: none;
		border-top: none;
	}

	:global(.hovered-project) {
		/* background-color: #DAD2BF !important; */
		filter: brightness(120%);
		outline: 3px solid var(--color-brand-500) !important;
		transition: outline 0.2s ease, filter 0.1s ease;
	}

	:global(.active-project) {
		filter: brightness(150%) !important;
		transition: outline 0.05s ease, filter 0.02s ease;
	}

	:global(.selected-project) {
		outline: 3px solid var(--color-brand-500) !important;
		filter: brightness(120%);
	}

	:global(.active-project) ~ .corner {
		border-width: 5px !important;
	}

	:global([data-project-card]) {
		outline: 3px solid transparent;
		transition: outline 0.2s ease, filter 0.1s ease;
		z-index: 1;
	}
</style>
