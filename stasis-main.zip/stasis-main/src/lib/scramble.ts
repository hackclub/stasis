import { gsap } from 'gsap';

interface ScrambleOptions {
	duration?: number;
	charset?: string;
	staggerMax?: number;
	delayMax?: number;
	threshold?: number;
	triggerOnce?: boolean;
	trigger?: 'intersect' | 'visible';
}

interface CharData {
	element: HTMLSpanElement;
	original: string;
	isStatic: boolean;
	locked: boolean;
	lockTime: number;
}

const defaultOptions: Required<ScrambleOptions> = {
	duration: 0.7,
	charset: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*',
	staggerMax: 0.3,
	delayMax: 0.2,
	threshold: 0.2,
	triggerOnce: true,
	trigger: 'intersect'
};

export function scramble(node: HTMLElement, options: ScrambleOptions = {}) {
	const opts = { ...defaultOptions, ...options };
	
	let characters: CharData[] = [];
	let observer: IntersectionObserver | null = null;
	let mutationObserver: MutationObserver | null = null;
	let isAnimating = false;
	let animationStartTime = 0;
	let tickerCallback: (() => void) | null = null;
	let hasTriggered = false;

	function getRandomChar(): string {
		return opts.charset[Math.floor(Math.random() * opts.charset.length)];
	}

	function processTextNodes(element: Node) {
		const walker = document.createTreeWalker(
			element,
			NodeFilter.SHOW_TEXT,
			null
		);

		const textNodes: Text[] = [];
		let currentNode: Node | null;
		
		while ((currentNode = walker.nextNode())) {
			const text = currentNode.textContent || '';
			if (text.trim().length > 0) {
				textNodes.push(currentNode as Text);
			}
		}

		textNodes.forEach((textNode) => {
			const text = textNode.textContent || '';
			const fragment = document.createDocumentFragment();
			const chars = text.split('');
			
			chars.forEach((char, index) => {
				if (char === ' ') {
					fragment.appendChild(document.createTextNode(' '));
					return;
				}
				
				const span = document.createElement('span');
				
				const isStatic = /[^\w]/.test(char);
				const totalChars = chars.length;
				const lockTime = isStatic ? 0 : Math.random() * opts.delayMax + (index / totalChars) * opts.staggerMax;
				
				span.textContent = isStatic ? char : getRandomChar();
				fragment.appendChild(span);
				
				characters.push({
					element: span,
					original: char,
					isStatic,
					locked: isStatic,
					lockTime: lockTime * 1000
				});
			});
			
			textNode.replaceWith(fragment);
		});
	}

	function scrambleChars() {
		if (!isAnimating) return;

		const elapsed = Date.now() - animationStartTime;
		let allLocked = true;

		for (const char of characters) {
			if (char.isStatic) continue;

			if (!char.locked) {
				if (elapsed >= char.lockTime) {
					char.locked = true;
					char.element.textContent = char.original;
				} else {
					char.element.textContent = getRandomChar();
					allLocked = false;
				}
			}
		}

		if (allLocked && elapsed >= opts.duration * 1000) {
			stopAnimation();
		}
	}

	function startAnimation() {
		if (isAnimating || (hasTriggered && opts.triggerOnce)) return;
		
		hasTriggered = true;
		isAnimating = true;
		animationStartTime = Date.now();
		
		tickerCallback = () => {
			scrambleChars();
		};
		
		gsap.ticker.add(tickerCallback);
	}

	function stopAnimation() {
		isAnimating = false;
		if (tickerCallback) {
			gsap.ticker.remove(tickerCallback);
			tickerCallback = null;
		}
	}

	processTextNodes(node);

	if (opts.trigger === 'intersect') {
		observer = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						startAnimation();
						if (opts.triggerOnce) {
							observer?.disconnect();
						}
					}
				});
			},
			{ threshold: opts.threshold }
		);

		observer.observe(node);
	} else if (opts.trigger === 'visible') {
		const checkVisibility = () => {
			const isVisible = node.offsetParent !== null && 
				window.getComputedStyle(node).display !== 'none' &&
				window.getComputedStyle(node).visibility !== 'hidden';
			
			if (isVisible) {
				startAnimation();
				if (opts.triggerOnce) {
					mutationObserver?.disconnect();
				}
			}
		};

		mutationObserver = new MutationObserver(() => {
			checkVisibility();
		});

		mutationObserver.observe(node.parentElement || document.body, {
			attributes: true,
			childList: true,
			subtree: true
		});

		setTimeout(checkVisibility, 0);
	}

	return {
		destroy() {
			stopAnimation();
			observer?.disconnect();
			mutationObserver?.disconnect();
		}
	};
}
