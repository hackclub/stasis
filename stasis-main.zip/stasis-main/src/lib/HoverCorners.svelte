<script lang="ts">
	import { onMount } from 'svelte';
	import { gsap } from 'gsap';

	interface Props {
		cornerSize?: number;
		borderWidth?: number;
		offset?: number;
		color?: string;
	}

	let { cornerSize = 14, borderWidth = 3, offset = 12, color = '#e89161' }: Props = $props();

	let containerRef: HTMLDivElement;
	let translateX = $state(0);
	let translateY = $state(0);
	let maxParallaxDistance = 20;
	let isActive = false;
	let activationDistance = 100;
	let deactivationDistance = 150;

	const getDistanceToElement = (mouseX: number, mouseY: number, rect: DOMRect): number => {
		const closestX = Math.max(rect.left, Math.min(mouseX, rect.right));
		const closestY = Math.max(rect.top, Math.min(mouseY, rect.bottom));
		const deltaX = mouseX - closestX;
		const deltaY = mouseY - closestY;
		return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
	};

	onMount(() => {
		const handleMouseMove = (e: MouseEvent) => {
			if (!containerRef) return;
			
			const rect = containerRef.getBoundingClientRect();
			const centerX = rect.left + rect.width / 2;
			const centerY = rect.top + rect.height / 2;
			
			const distance = getDistanceToElement(e.clientX, e.clientY, rect);
			
			const shouldActivate = !isActive && distance <= activationDistance;
			const shouldDeactivate = isActive && distance > deactivationDistance;
			
			if (shouldDeactivate) {
				isActive = false;
				
				gsap.to({ translateX, translateY }, {
					translateX: 0,
					translateY: 0,
					duration: 0.4,
					ease: 'power3.out',
					onUpdate: function() {
						const target = this.targets()[0];
						translateX = target.translateX;
						translateY = target.translateY;
					}
				});
				return;
			}
			
			if (shouldActivate || isActive) {
				if (shouldActivate) {
					isActive = true;
				}
				
				const directionX = e.clientX - centerX;
				const directionY = e.clientY - centerY;
				const totalDistance = Math.sqrt(directionX * directionX + directionY * directionY);
				
				const normalizedX = totalDistance > 0 ? directionX / totalDistance : 0;
				const normalizedY = totalDistance > 0 ? directionY / totalDistance : 0;
				
				const moveFactor = Math.min(distance / activationDistance, 1);
				const newTranslateX = normalizedX * moveFactor * maxParallaxDistance;
				const newTranslateY = normalizedY * moveFactor * maxParallaxDistance;
				
				gsap.to({ translateX, translateY }, {
					translateX: newTranslateX,
					translateY: newTranslateY,
					duration: shouldActivate ? 0.4 : 0.15,
					ease: shouldActivate ? 'power3.out' : 'power2.out',
					onUpdate: function() {
						const target = this.targets()[0];
						translateX = target.translateX;
						translateY = target.translateY;
					}
				});
			}
		};

		window.addEventListener('mousemove', handleMouseMove);

		return () => {
			window.removeEventListener('mousemove', handleMouseMove);
		};
	});
</script>

<div
	bind:this={containerRef}
	class="hover-corners-wrapper"
>
	<slot />
	<div class="corner corner-tl" style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {offset}px; --color: {color}; transform: translate({translateX}px, {translateY}px)"></div>
	<div class="corner corner-tr" style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {offset}px; --color: {color}; transform: translate({translateX}px, {translateY}px)"></div>
	<div class="corner corner-br" style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {offset}px; --color: {color}; transform: translate({translateX}px, {translateY}px)"></div>
	<div class="corner corner-bl" style="--size: {cornerSize}px; --border: {borderWidth}px; --offset: {offset}px; --color: {color}; transform: translate({translateX}px, {translateY}px)"></div>
</div>

<style>
	.hover-corners-wrapper {
		position: relative;
		display: inline-block;
	}

	.corner {
		position: absolute;
		width: var(--size);
		height: var(--size);
		border: var(--border) solid var(--color);
		pointer-events: none;
	}

	.corner-tl {
		top: calc(-1 * var(--offset));
		left: calc(-1 * var(--offset));
		border-right: none;
		border-bottom: none;
		transform-origin: center;
	}

	.corner-tr {
		top: calc(-1 * var(--offset));
		right: calc(-1 * var(--offset));
		border-left: none;
		border-bottom: none;
		transform-origin: center;
	}

	.corner-br {
		bottom: calc(-1 * var(--offset));
		right: calc(-1 * var(--offset));
		border-left: none;
		border-top: none;
		transform-origin: center;
	}

	.corner-bl {
		bottom: calc(-1 * var(--offset));
		left: calc(-1 * var(--offset));
		border-right: none;
		border-top: none;
		transform-origin: center;
	}


</style>
