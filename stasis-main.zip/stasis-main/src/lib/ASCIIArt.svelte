<script lang="ts">
	interface Props {
		art: string;
		horizontalPosition: number;
		verticalOffset?: string;
	}

	let { art, horizontalPosition, verticalOffset = "" }: Props = $props();
	
	let mouseX = $state(0);
	let mouseY = $state(0);
	let container: HTMLElement;
	
	function handleMouseMove(e: MouseEvent) {
		if (!container) return;
		const rect = container.getBoundingClientRect();
		mouseX = e.clientX - rect.left;
		mouseY = e.clientY - rect.top;
	}
</script>

<svelte:window onmousemove={handleMouseMove} />

<div
	bind:this={container}
	class="absolute max-sm:hidden pointer-events-none select-none -z-1"
	style="left: {horizontalPosition}%; transform: translate(-50%, {verticalOffset || "-50%"});"
>
	<pre class="text-cream-800/12 text-[0.7rem] leading-[1.2] whitespace-pre font-mono text-left">{art}</pre>
	<pre 
		class="absolute top-0 left-0 text-cream-800/25 text-[0.7rem] leading-[1.2] whitespace-pre font-mono text-left"
		style="
			mask-image: radial-gradient(circle 150px at {mouseX}px {mouseY}px, black 0%, transparent 100%);
			-webkit-mask-image: radial-gradient(circle 150px at {mouseX}px {mouseY}px, black 0%, transparent 100%);
		"
	>{art}</pre>
</div>
