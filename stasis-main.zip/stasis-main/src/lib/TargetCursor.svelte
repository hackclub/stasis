<script lang="ts">
	import { onMount } from 'svelte';
	import { gsap } from 'gsap';

	interface Props {
		targetSelector?: string;
		spinDuration?: number;
		hideDefaultCursor?: boolean;
	}

	let { targetSelector = '.cursor-target', spinDuration = 2, hideDefaultCursor = true }: Props = $props();

	let cursorRef: HTMLDivElement;
	let dotRef: HTMLDivElement;
	let cornersRef: NodeListOf<HTMLDivElement>;
	let spinTl: gsap.core.Timeline | null = null;

	const constants = {
		borderWidth: 12,
		cornerSize: 14,
		parallaxStrength: 0.00005
	};

	const moveCursor = (x: number, y: number) => {
		if (!cursorRef) return;
		gsap.to(cursorRef, {
			x,
			y,
			duration: 0.1,
			ease: 'power3.out'
		});
	};

	onMount(() => {
		if (!cursorRef) return;

		const originalCursor = document.body.style.cursor;
		if (hideDefaultCursor) {
			document.body.style.cursor = 'none';
		}

		const cursor = cursorRef;
		cornersRef = cursor.querySelectorAll<HTMLDivElement>('.target-cursor-corner');

		let activeTarget: Element | null = null;
		let currentTargetMove: ((ev: Event) => void) | null = null;
		let currentLeaveHandler: (() => void) | null = null;
		let isAnimatingToTarget = false;
		let resumeTimeout: ReturnType<typeof setTimeout> | null = null;

		const cleanupTarget = (target: Element) => {
			if (currentTargetMove) {
				target.removeEventListener('mousemove', currentTargetMove);
			}
			if (currentLeaveHandler) {
				target.removeEventListener('mouseleave', currentLeaveHandler);
			}
			currentTargetMove = null;
			currentLeaveHandler = null;
		};

		gsap.set(cursor, {
			xPercent: -50,
			yPercent: -50,
			x: window.innerWidth / 2,
			y: window.innerHeight / 2
		});

		const createSpinTimeline = () => {
			if (spinTl) {
				spinTl.kill();
			}
			spinTl = gsap
				.timeline({ repeat: -1 })
				.to(cursor, { rotation: '+=360', duration: spinDuration, ease: 'none' });
		};

		createSpinTimeline();

		const moveHandler = (e: MouseEvent) => moveCursor(e.clientX, e.clientY);
		window.addEventListener('mousemove', moveHandler);

		const scrollHandler = () => {
			if (!activeTarget || !cursorRef) return;

			const mouseX = gsap.getProperty(cursorRef, 'x') as number;
			const mouseY = gsap.getProperty(cursorRef, 'y') as number;

			const elementUnderMouse = document.elementFromPoint(mouseX, mouseY);
			const isStillOverTarget =
				elementUnderMouse &&
				(elementUnderMouse === activeTarget || elementUnderMouse.closest(targetSelector) === activeTarget);

			if (!isStillOverTarget) {
				if (currentLeaveHandler) {
					currentLeaveHandler();
				}
			}
		};

		window.addEventListener('scroll', scrollHandler, { passive: true });

		const mouseDownHandler = (): void => {
			if (!dotRef) return;
			gsap.to(dotRef, { scale: 0.7, duration: 0.3 });
			gsap.to(cursorRef, { scale: 0.9, duration: 0.2 });
		};

		const mouseUpHandler = (): void => {
			if (!dotRef) return;
			gsap.to(dotRef, { scale: 1, duration: 0.3 });
			gsap.to(cursorRef, { scale: 1, duration: 0.2 });
		};

		window.addEventListener('mousedown', mouseDownHandler);
		window.addEventListener('mouseup', mouseUpHandler);

		const enterHandler = (e: MouseEvent) => {
			const directTarget = e.target as Element;

			const allTargets: Element[] = [];
			let current = directTarget;
			while (current && current !== document.body) {
				if (current.matches(targetSelector)) {
					allTargets.push(current);
				}
				current = current.parentElement!;
			}

			const target = allTargets[0] || null;
			if (!target || !cursorRef || !cornersRef) return;

			if (activeTarget === target) return;

			if (activeTarget) {
				cleanupTarget(activeTarget);
			}

			if (resumeTimeout) {
				clearTimeout(resumeTimeout);
				resumeTimeout = null;
			}

			activeTarget = target;
			const corners = Array.from(cornersRef);
			corners.forEach(corner => {
				gsap.killTweensOf(corner);
			});
			gsap.killTweensOf(cursorRef, 'rotation');
			spinTl?.pause();

			gsap.set(cursorRef, { rotation: 0 });

			const updateCorners = (mouseX?: number, mouseY?: number) => {
				const rect = target.getBoundingClientRect();
				const cursorRect = cursorRef!.getBoundingClientRect();

				const cursorCenterX = cursorRect.left + cursorRect.width / 2;
				const cursorCenterY = cursorRect.top + cursorRect.height / 2;

				const [tlc, trc, brc, blc] = Array.from(cornersRef!);

				const { borderWidth, cornerSize, parallaxStrength } = constants;

				let tlOffset = {
					x: rect.left - cursorCenterX - borderWidth,
					y: rect.top - cursorCenterY - borderWidth
				};
				let trOffset = {
					x: rect.right - cursorCenterX + borderWidth - cornerSize,
					y: rect.top - cursorCenterY - borderWidth
				};
				let brOffset = {
					x: rect.right - cursorCenterX + borderWidth - cornerSize,
					y: rect.bottom - cursorCenterY + borderWidth - cornerSize
				};
				let blOffset = {
					x: rect.left - cursorCenterX - borderWidth,
					y: rect.bottom - cursorCenterY + borderWidth - cornerSize
				};

				if (mouseX !== undefined && mouseY !== undefined) {
					const targetCenterX = rect.left + rect.width / 2;
					const targetCenterY = rect.top + rect.height / 2;
					const mouseOffsetX = (mouseX - targetCenterX) * parallaxStrength;
					const mouseOffsetY = (mouseY - targetCenterY) * parallaxStrength;

					tlOffset.x += mouseOffsetX;
					tlOffset.y += mouseOffsetY;
					trOffset.x += mouseOffsetX;
					trOffset.y += mouseOffsetY;
					brOffset.x += mouseOffsetX;
					brOffset.y += mouseOffsetY;
					blOffset.x += mouseOffsetX;
					blOffset.y += mouseOffsetY;
				}

				const tl = gsap.timeline();
				const corners = [tlc, trc, brc, blc];
				const offsets = [tlOffset, trOffset, brOffset, blOffset];

				corners.forEach((corner, index) => {
					tl.to(
						corner,
						{
							x: offsets[index].x,
							y: offsets[index].y,
							duration: 0.2,
							ease: 'power2.out'
						},
						0
					);
				});
			};

			isAnimatingToTarget = true;
			updateCorners();

			setTimeout(() => {
				isAnimatingToTarget = false;
			}, 1);

			let moveThrottle: number | null = null;
			const targetMove = (ev: Event) => {
				if (moveThrottle || isAnimatingToTarget) return;
				moveThrottle = requestAnimationFrame(() => {
					const mouseEvent = ev as MouseEvent;
					updateCorners(mouseEvent.clientX, mouseEvent.clientY);
					moveThrottle = null;
				});
			};

			const leaveHandler = () => {
				activeTarget = null;
				isAnimatingToTarget = false;

				if (cornersRef) {
					const corners = Array.from(cornersRef);
					gsap.killTweensOf(corners);

					const { cornerSize } = constants;
					const positions = [
						{ x: -cornerSize * 1.5, y: -cornerSize * 1.5 },
						{ x: cornerSize * 0.5, y: -cornerSize * 1.5 },
						{ x: cornerSize * 0.5, y: cornerSize * 0.5 },
						{ x: -cornerSize * 1.5, y: cornerSize * 0.5 }
					];

					const tl = gsap.timeline();
					corners.forEach((corner, index) => {
						tl.to(
							corner,
							{
								x: positions[index].x,
								y: positions[index].y,
								duration: 0.3,
								ease: 'power3.out'
							},
							0
						);
					});
				}

				resumeTimeout = setTimeout(() => {
					if (!activeTarget && cursorRef && spinTl) {
						const currentRotation = gsap.getProperty(cursorRef, 'rotation') as number;
						const normalizedRotation = currentRotation % 360;

						spinTl.kill();
						spinTl = gsap
							.timeline({ repeat: -1 })
							.to(cursorRef, { rotation: '+=360', duration: spinDuration, ease: 'none' });

						gsap.to(cursorRef, {
							rotation: normalizedRotation + 360,
							duration: spinDuration * (1 - normalizedRotation / 360),
							ease: 'none',
							onComplete: () => {
								spinTl?.restart();
							}
						});
					}
					resumeTimeout = null;
				}, 50);

				cleanupTarget(target);
			};

			currentTargetMove = targetMove;
			currentLeaveHandler = leaveHandler;

			target.addEventListener('mousemove', targetMove);
			target.addEventListener('mouseleave', leaveHandler);
		};

		window.addEventListener('mouseover', enterHandler, { passive: true });

		return () => {
			window.removeEventListener('mousemove', moveHandler);
			window.removeEventListener('mouseover', enterHandler);
			window.removeEventListener('scroll', scrollHandler);
			window.removeEventListener('mousedown', mouseDownHandler);
			window.removeEventListener('mouseup', mouseUpHandler);

			if (activeTarget) {
				cleanupTarget(activeTarget);
			}

			spinTl?.kill();
			document.body.style.cursor = originalCursor;
		};
	});
</script>

<div bind:this={cursorRef} class="target-cursor-wrapper">
	<div bind:this={dotRef} class="target-cursor-dot"></div>
	<div class="target-cursor-corner corner-tl"></div>
	<div class="target-cursor-corner corner-tr"></div>
	<div class="target-cursor-corner corner-br"></div>
	<div class="target-cursor-corner corner-bl"></div>
</div>

<style>
	.target-cursor-wrapper,
	.target-cursor-dot,
	.target-cursor-corner,
	.corner-tl,
	.corner-tr,
	.corner-br,
	.corner-bl {
		opacity: 1;
	}

	.target-cursor-wrapper {
		position: fixed;
		top: 0;
		left: 0;
		width: 0;
		height: 0;
		pointer-events: none;
		z-index: 9999;
		transform: translate(-50%, -50%);
	}

	.target-cursor-dot {
		position: absolute;
		left: 50%;
		top: 50%;
		width: 6px;
		height: 6px;
		background: #e89161;
		border-radius: 50%;
		transform: translate(-50%, -50%);
		will-change: transform;
		display: none;
	}

	.target-cursor-corner {
		position: absolute;
		left: 50%;
		top: 50%;
		width: 14px;
		height: 14px;
		border: 3px solid #e89161;
		will-change: transform;
	}

	.corner-tl {
		transform: translate(-150%, -150%);
		border-right: none;
		border-bottom: none;
	}

	.corner-tr {
		transform: translate(50%, -150%);
		border-left: none;
		border-bottom: none;
	}

	.corner-br {
		transform: translate(50%, 50%);
		border-left: none;
		border-top: none;
	}

	.corner-bl {
		transform: translate(-150%, 50%);
		border-right: none;
		border-top: none;
	}

	@media only screen and (max-width: 600px) {
		.target-cursor-dot,
		.target-cursor-corner,
		.target-cursor-wrapper,
		.corner-bl,
		.corner-br,
		.corner-tl,
		.corner-tr {
			display: none;
		}
	}
</style>
