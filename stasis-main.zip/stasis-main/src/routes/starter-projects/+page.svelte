<script lang="ts">
	import MagneticCorners from '$lib/MagneticCorners.svelte';
	import NoiseOverlay from '$lib/NoiseOverlay.svelte';
	import PlaceholderProjectPreview from '$lib/starter-projects/PlaceholderProjectPreview.svelte';
	import ProjectPreview from '$lib/starter-projects/ProjectPreview.svelte';
	import ProjectGridHoverCorners from '$lib/starter-projects/ProjectGridHoverCorners.svelte';
	import { onMount } from 'svelte';
	import { fly, fade, scale } from 'svelte/transition';
	import gsap from 'gsap';

	const projects = [
		{
			id: 'hackpad',
			name: 'Hackpad',
			hours: 6,
			short_description: 'A PCB and a case for a custom macropad.',
			badges: []
		},
		{
			id: 'spotify-thing',
			name: 'LED Cube',
			hours: 8,
			short_description: 'A 3D LED display controlled by Arduino.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Synth Kit',
			hours: 10,
			short_description: 'Build a DIY analog synthesizer from scratch.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Smart Mirror',
			hours: 12,
			short_description: 'A Raspberry Pi powered two-way mirror.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Bot Arm',
			hours: 15,
			short_description: 'A 3D printed robotic arm with servo control.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Mini Drone',
			hours: 20,
			short_description: 'A custom quadcopter with FPV camera.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'GamePad',
			hours: 7,
			short_description: 'A wireless controller for retro gaming.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'VU Meter',
			hours: 5,
			short_description: 'An audio visualizer with RGB LEDs.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Weather Station',
			hours: 9,
			short_description: 'Track temperature, humidity, and pressure.',
			badges: []
		},
		{
			id: 'hackpad',
			name: 'Badge PCB',
			hours: 4,
			short_description: 'A wearable LED badge with animations.',
			badges: []
		}
	];

	let gridOffset = $state(0);
	let animationFrame: number;
	let gridEl: HTMLDivElement | undefined = $state();
	let placeholderCount = $state(0);
	let selectedProject = $state<string | null>(null);
	let selectedProjectIndex = $state<number | null>(null);
	let projectHeights = $state<number[]>(new Array(projects.length).fill(0));
	let maxHeight = $derived(Math.max(...projectHeights, 0));
	let hasSelectedOnce = $state(false);
	let isTransitioning = $state(false);
	let pendingIndex: number | null = null;
	let svgContainerEl: SVGSVGElement | undefined = $state();
	let rotationTweens: gsap.core.Tween[] = [];
	


	const actualProjects = projects.length;

	function handleProjectClick(index: number) {
		if (index === selectedProjectIndex) return;
		
		if (isTransitioning && hasSelectedOnce) {
			pendingIndex = index;
			return;
		}
		
		selectedProjectIndex = index;
		
		if (!hasSelectedOnce) {
			isTransitioning = true;
			setTimeout(() => {
				hasSelectedOnce = true;
				isTransitioning = false;
			}, 500);
		}
	}
	
	function handleIntroStart() {
		if (hasSelectedOnce) {
			isTransitioning = true;
		}
	}
	
	function handleIntroEnd() {
		if (hasSelectedOnce) {
			isTransitioning = false;
			if (pendingIndex !== null && pendingIndex !== selectedProjectIndex) {
				const next = pendingIndex;
				pendingIndex = null;
				handleProjectClick(next);
			}
		}
	}
	
	function handleOutroStart() {
		isTransitioning = true;
	}
	
	function handleOutroEnd() {
		if (pendingIndex === null) {
			isTransitioning = false;
		}
	}

	function updatePlaceholders() {
		if (!gridEl) return;
		const gridWidth = gridEl.offsetWidth;
		const cols = Math.floor(gridWidth / 176); // 11rem = 176px
		const itemsInLastRow = actualProjects % cols;
		
		if (itemsInLastRow === 0 || cols === 0) {
			placeholderCount = 0;
		} else {
			placeholderCount = cols - itemsInLastRow;
		}
	}

	$effect(() => {
		if (selectedProjectIndex !== null && rotationTweens.length > 0) {
			rotationTweens.forEach(tween => {
				gsap.to(tween, {
					timeScale: 8,
					duration: 0.15,
					ease: 'power2.out',
					onComplete: () => {
						gsap.to(tween, {
							timeScale: 1,
							duration: 0.8,
							ease: 'power1.out'
						});
					}
				});
			});
		}
	});

	onMount(() => {
		const animate = () => {
			gridOffset += 0.2;
			animationFrame = requestAnimationFrame(animate);
		};
		
		animationFrame = requestAnimationFrame(animate);

		updatePlaceholders();
		const resizeObserver = new ResizeObserver(updatePlaceholders);
		if (gridEl) resizeObserver.observe(gridEl);

		// GSAP animations for rotating lines
		if (svgContainerEl) {
			const lines = [
				{ from: 80, to: 200, duration: 60, direction: 1 },
				{ from: 200, to: 320, duration: 80, direction: -1 },
				{ from: 320, to: 600, duration: 105, direction: 1 },
				{ from: 600, to: 720, duration: 50, direction: -1 },
				{ from: 720, to: 1080, duration: 95, direction: 1 }
			];

			lines.forEach((line, i) => {
				// Animate both line groups (top and bottom)
				const lineGroup1 = svgContainerEl!.querySelector(`[data-line-group="${i}-1"]`);
				const lineGroup2 = svgContainerEl!.querySelector(`[data-line-group="${i}-2"]`);
				const square1a = svgContainerEl!.querySelector(`[data-square="${i}-1a"]`);
				const square1b = svgContainerEl!.querySelector(`[data-square="${i}-1b"]`);
				const square2a = svgContainerEl!.querySelector(`[data-square="${i}-2a"]`);
				const square2b = svgContainerEl!.querySelector(`[data-square="${i}-2b"]`);

				if (lineGroup1 && lineGroup2 && square1a && square1b && square2a && square2b) {
					// Rotate line groups
					const tween1 = gsap.to(lineGroup1, {
						rotation: 360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: '1100 650'
					});
					
					const tween2 = gsap.to(lineGroup2, {
						rotation: 360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: '1100 650'
					});

					// Counter-rotate squares
					const tween3 = gsap.to(square1a, {
						rotation: -360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: `1100 ${650 - line.from}`
					});
					
					const tween4 = gsap.to(square1b, {
						rotation: -360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: `1100 ${650 - line.to}`
					});
					
					const tween5 = gsap.to(square2a, {
						rotation: -360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: `1100 ${650 + line.from}`
					});
					
					const tween6 = gsap.to(square2b, {
						rotation: -360 * line.direction,
						duration: line.duration,
						repeat: -1,
						ease: 'none',
						svgOrigin: `1100 ${650 + line.to}`
					});
					
					rotationTweens.push(tween1, tween2, tween3, tween4, tween5, tween6);
				}
			});
		}

		return () => {
			if (animationFrame) {
				cancelAnimationFrame(animationFrame);
			}
			resizeObserver.disconnect();
			gsap.killTweensOf('*');
		};
	});
</script>

<style>
	:global(body) {
		background-color: var(--color-cream-850);
	}

	@keyframes slide-right {
		from {
			background-position: 0 0;
		}
		to {
			background-position: 3rem 0;
		}
	}

	.animate-slide {
		animation: slide-right 4s linear infinite;
	}
</style>


<svelte:head>
	<title>Starter Projects - Stasis</title>
</svelte:head>

<div class="bg-[linear-gradient(#40352999,#40352999),url(/noise-smooth-dark.png)] min-h-screen relative overflow-hidden z-0 px-2">
	<div 
		class="absolute inset-0 opacity-40 -z-1000 pointer-none"
		style="
			background-image: url(/grid-texture.png);
			background-size: 8rem 8rem;
			background-position: {gridOffset * Math.cos(30 * Math.PI / 180)}px {gridOffset * Math.sin(30 * Math.PI / 180)}px;
			image-rendering: pixelated;
		"
	></div>

	<div class="mb-20 ml-16 mt-16">
		<a href="/">
			<MagneticCorners activationDistance={35} deactivationDistance={45}>
				<button class="block bg-brand-500 p-6 font-mono relative cursor-pointer hover:bg-brand-400">
					<img src="/home-light.svg" alt="Home" class="w-8 h-8">
				</button>
			</MagneticCorners>
		</a>
	</div>

<!-- 	
	<button class="m-4 lg:m-16 w-20 h-20 hover:bg-cream-50/10 p-5 cursor-pointer">
		<img src="/home.svg" alt="Home" class="w-full h-full">
	</button>
	 -->
	<img src="/stasis-logo-white-center.svg" alt="" class="absolute -z-1 w-full mx-auto scale-110 translate-x-3 -translate-y-[calc(100%-2vw)] md:-translate-y-[calc(100%-4vw)] opacity-10">

	<div class="flex flex-col max-w-6xl mx-auto font-mono mb-8">
		<div class="bg-brand-500 text-cream-100 text-xl w-max px-4 py-2 relative after:bg-brand-500 after:absolute after:left-full after:top-0 after:h-full after:aspect-square after:[clip-path:polygon(0_0,0_100%,100%_100%)]">
			STARTER PROJECTS
		</div>
		<div class="bg-cream-950 w-full h-max border-2 border-brand-500 flex flex-col relative
					after:absolute after:left-full after:w-8 after:h-[calc(100%+4px-32px)] after:-top-0.5 after:bg-brand-500 
					before:absolute before:bg-brand-500 before:-bottom-0.5 before:left-full before:w-8 before:h-8 before:[clip-path:polygon(0_0,0_100%,100%_0)]">
			<!-- top stuff -->
			<div class="flex flex-row">
				<!-- preview -->
				<div class="border-cream-500 border-r-2 flex-3/5 relative overflow-clip min-h-[400px]">
					<p class="text-cream-500/20 absolute top-1 right-2 z-10">PREVIEW</p>
					<svg bind:this={svgContainerEl} class="w-full h-full absolute inset-0 z-0" viewBox="0 0 1400 800" preserveAspectRatio="xMidYMid slice">
						<!-- Concentric circles -->
						{#each [160, 400, 640, 1200, 1440, 2160] as diameter}
							<circle cx="1100" cy="650" r={diameter / 2} fill="none" stroke="#44382C" stroke-width="2" />
						{/each}
						
						<!-- Rotating lines with squares -->
						{#each [
							{ from: 80, to: 200, duration: 60, direction: 1 },
							{ from: 200, to: 320, duration: 80, direction: -1 },
							{ from: 320, to: 600, duration: 105, direction: 1 },
							{ from: 600, to: 720, duration: 50, direction: -1 },
							{ from: 720, to: 1080, duration: 95, direction: 1 }
						] as line, i}
							<!-- First line -->
							<g data-line-group="{i}-1">
								<!-- Line connecting circles -->
								<line x1="1100" y1={650 - line.from} x2="1100" y2={650 - line.to} stroke="#44382C" stroke-width="2" />
								
								<!-- Squares at intersection points (counter-rotated) -->
								<g data-square="{i}-1a">
									<rect x={1100 - 4} y={650 - line.from - 4} width="8" height="8" fill="#44382C" />
								</g>
								<g data-square="{i}-1b">
									<rect x={1100 - 4} y={650 - line.to - 4} width="8" height="8" fill="#44382C" />
								</g>
							</g>
							
							<!-- Second line (opposite side) -->
							<g data-line-group="{i}-2">
								<!-- Line connecting circles -->
								<line x1="1100" y1={650 + line.from} x2="1100" y2={650 + line.to} stroke="#44382C" stroke-width="2" />
								
								<!-- Squares at intersection points (counter-rotated) -->
								<g data-square="{i}-2a">
									<rect x={1100 - 4} y={650 + line.from - 4} width="8" height="8" fill="#44382C" />
								</g>
								<g data-square="{i}-2b">
									<rect x={1100 - 4} y={650 + line.to - 4} width="8" height="8" fill="#44382C" />
								</g>
							</g>
						{/each}
					</svg>
					
					{#if selectedProjectIndex === null}
						<div 
							class="absolute inset-0 flex items-center justify-center z-1"
							out:fade={{ duration: 300 }}
						>
							<p class="text-cream-500/50 text-2xl font-mono" out:scale={{ start: 0.95, duration: 300 }}>Select a project to see details</p>
						</div>
					{/if}
					
					{#if !hasSelectedOnce && selectedProjectIndex !== null}
						<div 
							class="absolute inset-0 w-full h-full z-1"
							in:fly={{ y: 500, duration: 500, opacity: 1 }}
							onintrostart={handleIntroStart}
							onintroend={handleIntroEnd}
						>
							<img 
								src="/projects/{projects[selectedProjectIndex].id}.png" 
								alt=""
								class="w-full h-full object-cover"
							/>
						</div>
					{:else if hasSelectedOnce && selectedProjectIndex !== null}
						{#key selectedProjectIndex}
							<div 
								class="absolute inset-0 w-full h-full z-1"
								in:fly={{ y: 500, duration: 500, opacity: 1 }}
								out:fly={{ y: -500, duration: 500, opacity: 1 }}
								onintrostart={handleIntroStart}
								onintroend={handleIntroEnd}
								onoutrostart={handleOutroStart}
								onoutroend={handleOutroEnd}
							>
								<img 
									src="/projects/{projects[selectedProjectIndex].id}.png" 
									alt=""
									class="w-full h-full object-cover"
								/>
							</div>
						{/key}
					{/if}
				</div>
				<!-- details -->
				<div class="flex-2/5 flex flex-col relative">
					<p class="text-cream-500/20 absolute top-1 right-2">DETAILS</p>
					
					<!-- Hidden measurement divs for all projects -->
					{#each projects as project, i}
						<div 
							class="flex flex-col space-y-3 px-4 py-12 absolute opacity-0 pointer-events-none"
							bind:clientHeight={projectHeights[i]}
						>
							<h2 class="text-brand-500 text-5xl mx-8">{project.name.toUpperCase()}</h2>
							<p class="text-cream-50 text-2xl mx-8">{project.hours} hours</p>
							<p class="text-cream-50 text-lg mx-8">{project.short_description}</p>
						</div>
					{/each}
					
					<!-- Visible project details -->
					<div 
						class="flex flex-col space-y-3 px-4 py-12"
						style="min-height: {maxHeight}px"
					>
						<h2 class="text-brand-500 text-5xl mx-8">{projects[selectedProjectIndex ?? 0].name.toUpperCase()}</h2>
						<p class="text-cream-50 text-2xl mx-8">~{projects[selectedProjectIndex ?? 0].hours} hours</p>
						<p class="text-cream-50 text-lg mx-8">{projects[selectedProjectIndex ?? 0].short_description}</p>
					</div>
					<div class="flex flex-row border-cream-500 border-y-2 relative z-10">
						<div class="flex-1/3 min-h-24 border-cream-500 border-r-2 relative">
							<p class="text-cream-500 absolute top-2 right-4">1</p>
						</div>
						<div class="flex-1/3 min-h-24 border-cream-500 border-r-2 relative">
							<p class="text-cream-500 absolute top-2 right-4">2</p>
						</div>
						<div class="flex-1/3 min-h-24 border-cream-500 relative">
							<p class="text-cream-500 absolute top-2 right-4">3</p>
						</div>
					</div>
					<!-- <button class="text-cream-50 text-2xl w-full py-8 cursor-pointer relative overflow-hidden group">
						<span class="block overflow-hidden absolute w-full">
							<span class="block group-hover:-translate-y-full transition-all ease-out group-hover:opacity-70">
								GUIDE
							</span>
						</span>
						<span class="block overflow-hidden relative z-10">
							<span class="block group-[:not(:hover)]:translate-y-full group-[:not(:hover)]:opacity-70 transition-all ease-out text-brand-900">
								GUIDE
							</span>
						</span>
						<div class="absolute left-0 bottom-0 w-full h-0 bg-brand-500 group-hover:h-full transition-all ease-out border-brand-900/20 border-r-3"></div>
					</button> -->
					<button class="text-brand-900 text-2xl w-full py-8 cursor-pointer relative overflow-hidden group z-1 hover:brightness-110 transition-[filter] duration-50 bg-brand-500 border-brand-900/20 border-r-3">
						<div class="-z-1 absolute w-full h-full inset-0 bg-size-[3rem_3rem] animate-slide" style="background-image: linear-gradient(135deg, #ea745225 0%, #ea745225 12.5%, transparent 12.5%, transparent 37.5%, #ea745225 37.5%, #ea745225 62.5%, transparent 62.5%, transparent 87.5%, #ea745225 87.5%, #ea745225 100%)"></div>
						<div class="z-1 absolute w-full h-full inset-0 bg-linear-to-b from-cream-100/10 to-cream-100/0 opacity-0 group-hover:opacity-100 transition-opacity"></div>
						<span class="block overflow-hidden absolute w-full">
							<span class="block group-hover:translate-y-full transition-all ease-out group-hover:opacity-70">
								GUIDE
							</span>
						</span>
						<span class="block overflow-hidden">
							<span class="block group-[:not(:hover)]:-translate-y-full transition-all ease-out group-[:not(:hover)]:opacity-70">
								GUIDE
							</span>
						</span>
					</button>
				</div>
			</div>
			<!-- grid of projects -->
			<div bind:this={gridEl} class="grid grid-cols-[repeat(auto-fit,minmax(11rem,1fr))] gap-0.5 bg-cream-500 relative overflow-hidden cursor-pointer pt-0.5">
				<p class="text-cream-500/20 absolute top-1 right-2 z-2">PROJECTS</p>
				<ProjectGridHoverCorners {gridEl} selectedIndex={selectedProjectIndex} />
				{#each projects as project, i}
					<ProjectPreview {project} selected={selectedProjectIndex === i} onclick={() => handleProjectClick(i)} />
				{/each}
				{#each Array(placeholderCount)}
					<PlaceholderProjectPreview />
				{/each}
			</div>
		</div>
	</div>

	<footer class="pt-20 pb-24 relative px-4">
		<div class="mx-auto max-w-md w-max font-mono">
			<p class="text-xs md:text-sm text-cream-600 text-center">Made with <span class="bg-brand-500 text-cream-100">&lt;3</span> by teenagers, for teenagers</p>
			<div class="mt-2 text-cream-600 text-center">
				<a href="https://hackclub.com" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Hack Club</a>
				<span>・</span>
				<a href="https://hackclub.com/slack" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Slack</a>
				<span>・</span>
				<a href="https://hackclub.com/clubs" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100">Clubs</a>
				<span>・</span>
				<a href="https://hackclub.com/hackathons" target="_blank" rel="noopener" class="underline text-xs md:text-sm hover:bg-brand-500 hover:text-cream-100"
					>Hackathons</a
				>
			</div>
		</div>
	</footer>

	<!-- footer darkening background -->
	<div class="absolute bottom-0 left-0 w-full h-48 bg-[linear-gradient(#42382C00,#392E22)] -z-2"></div>
</div>

<NoiseOverlay />