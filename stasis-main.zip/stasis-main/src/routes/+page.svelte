<script lang="ts">
	import PageBorder from '$lib/PageBorder.svelte';
	import DottedLine from '$lib/DottedLine.svelte';
	import NoiseOverlay from '$lib/NoiseOverlay.svelte';
	import MagneticCorners from '$lib/MagneticCorners.svelte';
	import HoverScramble from '$lib/HoverScramble.svelte';
	import ASCIIArt from '$lib/ASCIIArt.svelte';
	import { scramble } from '$lib/scramble';
	import { slide } from 'svelte/transition';
	import { asciiArt } from '$lib/ascii-art';

	let openIndex = $state<number | null>(null);
	let footerHeight = $state(0);

	const faqs = [
		{
			question: "How do I qualify for Stasis?",
			answer: "Design a hardware project that uses 3 of the skills listed, and we'll send you money to build it! When you've built your project, you've earned those 3 badges. Once you earn 6 badges, you've qualified for Stasis, and we'll reserve your spot."
		},
		{
			question: "How many spots are there?",
			answer: "Stasis will have 100 teenagers from all over the world, with spots being first come first serve, so get started as soon as you can!"
		},
		{
			question: "I don't know hardware!",
			answer: "Don't worry! Stasis is 100% beginner friendly, we have a ton of starter projects for you to start learning skills, and if you complete and build a starter project, you can get 3 badges!"
		},
		{
			question: "Wait, I can get badges from learning hardware?",
			answer: "Yes! If you follow a starter project's tutorial and build it, you can earn up to 3 badges. This can only be done once, however, so you can't complete 2 starter projects and get 6 badges."
		},
		{
			question: "What does 50/50 mean?",
			answer: "Stasis will have an equal split of hackers that are male-identifying and hackers that are underrepresented in tech because of their gender. If you identify with a gender that is a minority in STEM, then you fall in the underrepresented 50. If you identify with a gender that is a majority in STEM, you fall into the male-identifying 50."
		},
		// {
		// 	question: "I want to make a project but the skill it uses isn't listed.",
		// 	answer: "Fill out <a href='#'>this</a> form! We'll check it out."
		// },
		{
			question: "Is this legit? What's Hack Club?",
			answer: "<a href='https://hackclub.com'>Hack Club</a> is the world's largest community of teenage makers, and a 501(c)(3) nonprofit. Hack Club is supported by donations from tech companies like GitHub and invidiuals like Michael Dell. Hack Club is <a href='https://hcb.hackclub.com/hq'>fiscally transparent</a>."
		},
		{
			question: "Who's eligible?",
			answer: "To be eligible for Stasis, you must be between the ages of 13 and 18 (<b>inclusive</b>), and you must be able to attend the event in person."
		},
		{
			question: "I have more questions!",
			answer: "Join the <a href='https://hackclub.com/slack'>Hack Club Slack</a> and head to the <a href='https://hackclub.slack.com/archives/C09HSQM550A'>#stasis</a> channel! You can also email us at <a href='mailto:stasis@hackclub.com'>stasis@hackclub.com</a>."
		}
	];

	function toggle(index: number) {
		openIndex = openIndex === index ? null : index;
	}

	function handleClick(event: MouseEvent) {
		if ((event.target as HTMLElement).tagName === 'A') {
			event.stopPropagation();
		}
	}
</script>

<svelte:head>
	<title>Stasis - Hack Club Hardware Hackathon</title>
</svelte:head>

<div class="bg-[linear-gradient(#DAD2BF99,#DAD2BF99),url(/noise-smooth.png)] font-mono text-cream-800 bg-container">

	<div class="min-h-screen relative md:pt-12 z-0" style="padding-bottom: {footerHeight}px;">
		<div class="mx-auto max-w-md pt-32 pb-24 md:py-24 *:py-8 *:md:py-16">
		<div class="absolute left-1/2 top-0 h-full w-full max-w-md -translate-x-1/2 pointer-events-none md:block hidden">
			<div class="absolute left-0 top-0 h-full">
				<DottedLine orientation="vertical" />
			</div>
			<div class="absolute right-0 top-0 h-full">
				<DottedLine orientation="vertical" />
			</div>
		</div>
		
		<div class="space-y-12 px-4 md:px-2">
			<header class="text-center">
				
				<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
					<DottedLine orientation="horizontal" />
				</div>


				<!-- <img src="/stasis-logo.svg" alt="Stasis" class="mb-4 py-1 w-full h-auto" /> -->
				<div class="mb-4 py-1 w-full h-auto relative">
					<img src="/stasis-logo.svg" alt="Hack Club Stasis" class="absolute max-md:-translate-x-[5%] md:scale-[116%] -translate-y-[28%] md:origin-bottom-right select-none pointer-events-none">
					<img src="/stasis-text.svg" alt="" class="opacity-0 pointer-events-none select-none">
				</div>

				<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
					<DottedLine orientation="horizontal" />
				</div>

				<ASCIIArt art={asciiArt.hackclub} horizontalPosition={80} />

				<ASCIIArt art={asciiArt.earth} horizontalPosition={35} />

				<HoverScramble 
				segments={[
					{ text: "GAXX F I GYI TIMK G PRCQJJMS R\nBCU" },
					{ text: "50/50 HARDWARE HACKATHON", class: "text-cream-800" },
					{ text: "EMD\n" },
					{ text: "FEBRUARY 2026", class: "text-cream-800" },
					{ text: "J R" },
					{ text: "AUSTIN, TEXAS", class: "text-cream-800" },
					{ text: "P\nFCX XW VQQET S" },
					{ text: "COMPLETELY FREE", class: "text-cream-800" },
					{ text: "M\nC LQW" },
					{ text: "FLIGHT STIPENDS AVAILABLE", class: "text-cream-800" },
					{ text: "\nC" },
					{ text: "HIGH SCHOOLERS ONLY", class: "text-cream-800" },
					{ text: "MEXDLB LEZ\nYRE\tVJ URVSP LWOS JWPOX I SFF" }
				]}
				initialScramble={true}
				initialDuration={2.5}
				initialStagger={1.2}
				initialDelay={0.8}
				continuousScramble={false}
				continuousSpeed={25}
				class="font-mono text-[1.1rem] md:text-[1.4rem] text-cream-800/20 leading-tight w-full origin-center block whitespace-pre-line bg-[#DAD2BF50]"
				/>
				<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
					<DottedLine orientation="horizontal" />
				</div>
			</header>

			<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
				<DottedLine orientation="horizontal" />
			</div>
			
			
			<div class="flex justify-center pt-2 pb-1.5 mb-0 z-1 relative">
				<MagneticCorners offset={12}>
					<MagneticCorners mode="border" color={"#D95D39"} magnetStrength={0.025} hoverOffsetIncrease={1} hoverColor={"#e89161"}>
						<button class="relative bg-brand-500 hover:bg-[#e0643e] px-8 md:px-10 py-2 text-xl md:text-2xl uppercase tracking-wider text-brand-900 transition-colors cursor-pointer">
							RSVP
						</button>
					</MagneticCorners>
				</MagneticCorners>
			</div>

			<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
				<DottedLine orientation="horizontal" />
			</div>

			<p class="text-xs md:text-sm text-center mt-4 text-cream-800/90">Event launches December 2025</p>

			<!-- <div class="mb-[max(4rem,12vh)]"></div> -->
			<div class="h-1"></div>

			<!-- <ASCIIArt art={asciiArt.earth} horizontalPosition={35} /> -->
			<!-- <ASCIIArt art={asciiArt.earth} horizontalPosition={20} /> -->

			<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
				<DottedLine orientation="horizontal" />
			</div>

			
			<section class="space-y-4">
			<!-- <section class="space-y-4 relative before:absolute before:-inset-6 mb-18 mt-22 before:border-cream-500 before:border z-0 before:-z-1"> -->
				<h2 class="text-lg md:text-xl uppercase tracking-wide" use:scramble={{ threshold: 0, duration: 1.2, staggerMax: 0.6, delayMax: 0.4 }}>
					How You Qualify
			        <img src="/pixel-arrow.png" alt="" class="inline-block pixelated" style="height: 0.9em; image-rendering: pixelated; transform: translateY(-0.11em)" />
				</h2>
				<ul class="space-y-2 text-sm md:text-base [&>li]:pl-4 [&>li]:-indent-4">
					<li use:scramble={{ threshold: 0, duration: 1.2, staggerMax: 0.6, delayMax: 0.4 }}>· Design hardware projects using three hardware skills, get $$ to build it</li>
					<li use:scramble={{ threshold: 0, duration: 1.2, staggerMax: 0.6, delayMax: 0.4 }}>· Earn a badge for each skill you learn</li>
					<li use:scramble={{ threshold: 0, duration: 1.2, staggerMax: 0.6, delayMax: 0.4 }}>· Get six badges and fly to Austin, TX! (travel stipends available)</li>
				</ul>
			</section>

			<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
				<DottedLine orientation="horizontal" />
			</div>
			
			<ASCIIArt art={asciiArt.fish} horizontalPosition={65} />

			<section class="space-y-4">
				<h2 class="text-lg md:text-xl uppercase tracking-wide" use:scramble>Badges You Can Earn</h2>
				<ul class="space-y-1 text-sm md:text-base [&>li]:pl-4 [&>li]:-indent-4">
					<li use:scramble>· Lorem Ipsum</li>
					<li use:scramble>· Dolor sit</li>
					<li use:scramble>· Lorem Ipsum</li>
					<li use:scramble>· Dolor sit</li>
					<li use:scramble>· Dolor sit</li>
					<li use:scramble>· Lorem Ipsum</li>
					<li use:scramble>· Dolor sit</li>
					<li use:scramble>· Lorem Ipsum</li>
				</ul>
			</section>

			<div class="absolute left-1/2 w-screen h-px -translate-x-1/2">
				<DottedLine orientation="horizontal" />
			</div>
			
			<ASCIIArt art={asciiArt.cat} horizontalPosition={85} />

			<ASCIIArt art={asciiArt.roflcopter} horizontalPosition={35} verticalOffset="30rem" />
				
			<ASCIIArt art={asciiArt.duck} horizontalPosition={90} verticalOffset="28rem" />

			<ASCIIArt art={asciiArt.donut} horizontalPosition={12}	 />

			<section class="space-y-4 mb-12">
				<h2 class="text-lg md:text-xl uppercase tracking-wide mb-4" use:scramble>Frequently Asked Questions</h2>
				<div>
					{#each faqs as faq, i}
						<div class="border-b border-cream-800/20">
							<button
								onclick={(e) => { handleClick(e); toggle(i); }}
								class="w-full text-left text-sm md:text-base cursor-pointer"
							>
								<div class="flex items-center justify-between py-2.5">
									<span use:scramble={{ duration: 0.4, staggerMax: 0.15, delayMax: 0.1 }}>{faq.question}</span>
									<span 
										class="text-xl transition-transform duration-300 ease-out ml-4 mr-2"
										style="transform: rotate({openIndex === i ? 45 : 0}deg)"
									>
										+
									</span>
								</div>
								{#if openIndex === i}
									<div transition:slide={{ duration: 300 }} class="pb-2.5 pr-8 text-cream-800/70 faq">
										{@html faq.answer}
									</div>
								{/if}
							</button>
						</div>
					{/each}
				</div>
			</section>
			
			
		</div>

		</div>
	</div>

	<PageBorder onFooterHeightChange={(h) => footerHeight = h} />
</div>
<NoiseOverlay /> 

<style>
	:global(.faq a) {
		text-decoration: underline;
		color: var(--color-brand-500);
	}
	:global(.faq a:hover) {
		background-color: var(--color-brand-500);
		color: var(--color-cream-100);
	}

	:global(body) {
		background-color: var(--color-cream-100);
	}

	.bg-container::before {
		content: '';
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: linear-gradient(#DAD2BF99, #DAD2BF99), url(/noise-smooth.png);
		pointer-events: none;
		z-index: -1;
	}
</style>