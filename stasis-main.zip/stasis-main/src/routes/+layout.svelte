<script lang="ts">
	import '../app.css';
	import favicon from '$lib/assets/favicon.svg';
	import AsteroidCat from '$lib/AsteroidCat.svelte';

	let { children } = $props();
	let asteroidCat: AsteroidCat;
	
	if (typeof window !== 'undefined') {
		(window as any).__stasisPageWrapper = null;
		(window as any).__stasisAsteroidCat = null;
	}
	
	$effect(() => {
		if (typeof window !== 'undefined') {
			(window as any).__stasisAsteroidCat = asteroidCat;
		}
	});
</script>

<svelte:head>
	<link rel="icon" href={favicon} />
</svelte:head>

<div bind:this={(window as any).__stasisPageWrapper}>
	{@render children()}
</div>

<AsteroidCat bind:this={asteroidCat} />
